

<?php $__env->startSection('title', 'Download ' . $year . ' Videos Here | TrendySongz'); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="Download Latest Videos - Latest Music Videos, Latest Nigerian Music Videos mp4, Download Latest Naija Music Videos mp4">
    <meta name="keywords" content="download latest videos, latest naija music videos, download latest naija music video, download latest naija video, latest naija video">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e(route('pages.videos_released_year', $year)); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="TrendySongz">
    <meta property="og:title" content="Download <?php echo e($year); ?> Videos Here | TrendySongz">
    <meta property="og:description" content="Download Latest Videos - Latest Music Videos, Latest Nigerian Music Videos mp4, Download Latest Naija Music Videos mp4">
    <meta property="og:url" content="<?php echo e(route('pages.videos_released_year', $year)); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="Download <?php echo e($year); ?> Videos Here | TrendySongz">
    <meta name="twitter:description" content="Download Latest Videos - Latest Music Videos, Latest Nigerian Music Videos mp4, Download Latest Naija Music Videos mp4">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-videos-page">
        <header class="ts-video-page-heading">
            <h1>Download <?php echo e($year); ?> Naija Videos Released Here</h1>

            <time class="post-date" datetime="<?php echo e(now()->toDateString()); ?>">
                <?php echo e(now()->format('M d, Y')); ?>

            </time>
        </header>

        <div class="ts-video-list">
            <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a
                    class="ts-video-list-item"
                    href="<?php echo e(route('pages.videos_detail', [
                        $row->id,
                        \Illuminate\Support\Str::slug(
                            trim(
                                ($row->ArtistsName ?? '')
                                . ' '
                                . ($row->TrackTitle ?? '')
                            )
                        ),
                    ])); ?>"
                >
                    <div class="ts-video-list-cover">
                        <?php echo $__env->make('pages.partials.cover', [
                            'src' => $row->CoverUrl,
                            'folder' => '',
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <span class="ts-video-list-play" aria-hidden="true">
                            <i class="fa fa-play"></i>
                        </span>
                    </div>

                    <div class="ts-video-list-info">
                        <?php if($row->ArtistsName): ?>
                            <span class="ts-video-list-artist">
                                <?php echo e($row->ArtistsName); ?>

                            </span>
                        <?php endif; ?>

                        <span class="ts-video-list-title">
                            <?php echo e($row->TrackTitle); ?>

                        </span>

                        <?php if($row->Featuring): ?>
                            <span class="ts-video-list-featuring">
                                <span>Featuring:</span> <?php echo e($row->Featuring); ?>

                            </span>
                        <?php endif; ?>

                        <?php if($row->directedby): ?>
                            <span class="ts-video-list-directed">
                                <span>Directed by:</span> <?php echo e($row->directedby); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="ts-videos-empty">
                    No videos found for <?php echo e($year); ?>.
                </p>
            <?php endif; ?>
        </div>

        <?php if($videos->hasPages()): ?>
            <div class="ts-video-pagination">
                <?php echo e($videos->links()); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/videos_year.blade.php ENDPATH**/ ?>