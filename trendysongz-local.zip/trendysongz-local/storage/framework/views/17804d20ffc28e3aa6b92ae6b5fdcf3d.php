<?php $__env->startSection('title', 'Add listing'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Add audio or video</h1>

    <p>
        Add and publish the artist first. Albums are optional and must belong
        to the selected artist.
    </p>

    <?php echo $__env->make('admin.listings.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/listings/create.blade.php ENDPATH**/ ?>