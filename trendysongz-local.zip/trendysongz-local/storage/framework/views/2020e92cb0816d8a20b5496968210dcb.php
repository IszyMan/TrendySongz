

<?php
    $pageTitle = "Download Latest {$year} Albums Here | TrendySongz";
    $description = "Download Latest {$year} Albums, Download Latest {$year} Naija Albums, Download {$year} Album mp3, download {$year} music album";
    $keywords = "Download Latest {$year} album, Download Latest {$year} Naija album, Download {$year} album mp3, download {$year} music albums, Download {$year} Naija Music Albums";

    $pageUrl = $albums->currentPage() === 1
        ? route('pages.albums_released_year', ['year' => $year])
        : $albums->url($albums->currentPage());
?>

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($description); ?>">
    <meta name="keywords" content="<?php echo e($keywords); ?>">
    <meta name="author" content="Wilfred Moses">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e($pageUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="TrendySongz">
    <meta property="og:title" content="<?php echo e($pageTitle); ?>">
    <meta property="og:description" content="<?php echo e($description); ?>">
    <meta property="og:url" content="<?php echo e($pageUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="<?php echo e($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($description); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-artists-albums">
        <header class="ts-section-heading">
            <h1>Download <?php echo e($year); ?> Nigerian, Ghana and African music albums</h1>

            <!--<p class="ts-albums-subheading">
                Download <?php echo e($year); ?> Nigerian, Ghana and African music albums
            </p>-->
        </header>

        <div class="ts-albums-date">
            <time datetime="<?php echo e(now()->toDateString()); ?>">
                <?php echo e(now()->format('M d, Y')); ?>

            </time>
        </div>

        <div class="ts-artists-albums-list">
            <?php $__empty_1 = true; $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $albumSlug = \Illuminate\Support\Str::slug(
                        trim(($row->ArtistsName ?? '') . ' ' . $row->title)
                    );
                ?>

                <a
                    class="ts-artist-album-card"
                    href="<?php echo e(route('pages.album_details', [
                        $row->id,
                        $albumSlug,
                    ])); ?>"
                >
                    <div class="ts-artist-album-cover">
                        <?php echo $__env->make('pages.partials.cover', [
                            'src' => $row->cover_url,
                            'folder' => '',
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>

                    <div class="ts-artist-album-details">
                        <?php if($row->ArtistsName): ?>
                            <span class="ts-artist-album-artist">
                                <?php echo e($row->ArtistsName); ?>

                            </span>
                        <?php endif; ?>

                        <h2 class="ts-artist-album-title">
                            <?php echo e($row->title); ?>

                        </h2>

                        <?php if($row->featuring): ?>
                            <p class="ts-artist-album-featuring">
                                Featuring <?php echo e($row->featuring); ?>

                            </p>
                        <?php endif; ?>

                        <div class="ts-artist-album-meta">
                            <?php if($row->released_year): ?>
                                <span class="ts-artist-album-meta-row">
                                    Released: <?php echo e($row->released_year); ?>

                                </span>
                            <?php endif; ?>

                            <span class="ts-artist-album-meta-row">
                                <?php echo e($row->track_count); ?>

                                <?php echo e($row->track_count == 1 ? 'Track' : 'Tracks'); ?>

                            </span>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="ts-artists-albums-empty">
                    No <?php echo e($year); ?> albums or EPs found.
                </p>
            <?php endif; ?>
        </div>

        <?php if($albums->hasPages()): ?>
            <div>
                <?php echo e($albums->onEachSide(1)->links('vendor.pagination.trendysongz')); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/albums_year.blade.php ENDPATH**/ ?>