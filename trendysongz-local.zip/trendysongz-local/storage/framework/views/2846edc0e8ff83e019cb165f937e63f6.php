<?php
    $editing = isset($row);
?>

<form
    class="admin-panel admin-grid"
    method="POST"
    action="<?php echo e($editing
        ? route('admin.listings.update', $row->id)
        : route('admin.listings.store')); ?>"
    enctype="multipart/form-data"
>
    <?php echo csrf_field(); ?>

    <?php if($editing): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <label>
        Artist

        <select name="Artists_Id" id="listing-artist" required>
            <option value="">Choose artist</option>

            <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($artist->Artists_Id); ?>"
                    <?php if(old('Artists_Id', $row->Artists_Id ?? '') === $artist->Artists_Id): echo 'selected'; endif; ?>
                >
                    <?php echo e($artist->ArtistsName ?: $artist->Stage_Name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <label>
        Album (optional)

        <select name="album_id" id="listing-album">
            <option value="">No album / single</option>

            <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($album->id); ?>"
                    data-artist="<?php echo e($album->artist_id); ?>"
                    <?php if((string) old('album_id', $row->album_id ?? '') === (string) $album->id): echo 'selected'; endif; ?>
                >
                    <?php echo e($album->title); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <label>
        Country

        <select name="country_id" required>
            <?php $__currentLoopData = [
                'naija' => 'Nigeria',
                'ghana' => 'Ghana',
                'african' => 'Other African country',
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($value); ?>"
                    <?php if(old('country_id', $row->country_id ?? 'naija') === $value): echo 'selected'; endif; ?>
                >
                    <?php echo e($label); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <label>
        Type

        <select name="ListingType" id="listing-type" required>
            <option
                value="audio"
                <?php if(old('ListingType', $row->ListingType ?? 'audio') === 'audio'): echo 'selected'; endif; ?>
            >
                Audio
            </option>

            <option
                value="video"
                <?php if(old('ListingType', $row->ListingType ?? 'audio') === 'video'): echo 'selected'; endif; ?>
            >
                Video
            </option>
        </select>
    </label>

    <label class="admin-wide">
        Track / video title

        <input
            name="TrackTitle"
            maxlength="1000"
            value="<?php echo e(old('TrackTitle', $row->TrackTitle ?? '')); ?>"
            required
        >
    </label>

    <label>
        Featuring

        <input
            name="Featuring"
            maxlength="500"
            value="<?php echo e(old('Featuring', $row->Featuring ?? '')); ?>"
        >
    </label>

    <label>
        Year of release

        <input
            name="YearOfRelease"
            maxlength="100"
            value="<?php echo e(old('YearOfRelease', $row->YearOfRelease ?? '')); ?>"
        >
    </label>

    <label>
        Produced by

        <input
            name="producedby"
            maxlength="500"
            value="<?php echo e(old('producedby', $row->producedby ?? '')); ?>"
        >
    </label>

    <label>
        Directed by (videos)

        <input
            name="directedby"
            maxlength="36"
            value="<?php echo e(old('directedby', $row->directedby ?? '')); ?>"
        >
    </label>

    <label>
        Album track number

        <input
            type="number"
            min="1"
            name="track_number"
            value="<?php echo e(old('track_number', $row->track_number ?? 1)); ?>"
        >
    </label>

    <label>
        Cover image

        <input
            type="file"
            name="image"
            accept="image/jpeg,image/png,image/webp"
        >

        <?php if($editing && $row->CoverUrl): ?>
            <span class="admin-file-note">
                Current: <?php echo e($row->CoverUrl); ?>. Leave empty to keep it.
            </span>
        <?php endif; ?>
    </label>

    <label class="admin-wide">
        Media file (200 MB maximum)

        <input
            type="file"
            name="media"
            id="listing-media"
            <?php if(! $editing): echo 'required'; endif; ?>
        >

        <?php if($editing && $row->TrackUrl): ?>
            <span class="admin-file-note">
                Current: <?php echo e($row->TrackUrl); ?>. Leave empty to keep it.
            </span>
        <?php endif; ?>
    </label>

    <label class="admin-wide">
        Introduction

        <textarea name="introduction"><?php echo e(old('introduction', $row->introduction ?? '')); ?></textarea>
    </label>

    <label class="admin-wide">
        Track information

        <textarea
            name="TrackInfo"
            maxlength="5000"
        ><?php echo e(old('TrackInfo', $row->TrackInfo ?? '')); ?></textarea>
    </label>

    <label class="admin-wide">
        Additional track information 1

        <textarea
            name="trackinfo1"
            maxlength="5000"
        ><?php echo e(old('trackinfo1', $row->trackinfo1 ?? '')); ?></textarea>
    </label>

    <label class="admin-wide">
        Additional track information 2

        <textarea
            name="trackinfo2"
            maxlength="5000"
        ><?php echo e(old('trackinfo2', $row->trackinfo2 ?? '')); ?></textarea>
    </label>

    <input type="hidden" name="isgospel" value="0">

    <label class="admin-check">
        <input
            type="checkbox"
            name="isgospel"
            value="1"
            <?php if(old('isgospel', $row->isgospel ?? 0)): echo 'checked'; endif; ?>
        >
        Gospel
    </label>

    <input type="hidden" name="publish" value="0">

    <label class="admin-check">
        <input
            type="checkbox"
            name="publish"
            value="1"
            <?php if(old('publish', isset($row) && $row->IsPublished === 'YES')): echo 'checked'; endif; ?>
        >
        Published
    </label>

    <div class="admin-wide">
        <button class="admin-button" type="submit">
            <?php echo e($editing ? 'Save changes' : 'Save listing'); ?>

        </button>
    </div>
</form>

<script src="<?php echo e(asset('js/admin-listing.js')); ?>" defer></script><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/listings/form.blade.php ENDPATH**/ ?>