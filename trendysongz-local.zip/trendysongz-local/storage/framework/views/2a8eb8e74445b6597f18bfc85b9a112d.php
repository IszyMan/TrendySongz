<?php
    $popularArtistes = [
        '2Baba' => '2baba',
        'Burna Boy' => 'burna-boy',
        'JoeBoy' => 'joeboy',
        'Davido' => 'davido',
        'Zlatan' => 'zlatan',
        'Falz' => 'falz',
        'Fire Boy' => 'fireboy-dml',
        'Kizz Daniel' => 'kizz-daniel',
        'Rema' => 'rema',
        'Mayorkun' => 'mayorkun',
        'Naira Marley' => 'naira-marley',
        'Simi' => 'simi',
        'Wizkid' => 'wizkid',
        'Phyno' => 'phyno',
        'Olamide' => 'olamide',
        'Omah Lay' => 'omah-lay',
        'Wande Coal' => 'wande-coal',
        'Tiwa Savage' => 'tiwa-savage',
        'Patoranking' => 'patoranking',
        'Mr Eazi' => 'mr-eazi',
        'Bella Shmurda' => 'bella-shmurda',
        'Zinoleesky' => 'zinoleesky',
    ];

    $starArtistes = [
        'Adekunle Gold' => 'adekunle-gold',
        'Skales' => 'skales',
        'Niniola' => 'niniola',
        'T Classic' => 't-classic',
        'Ladipoe' => 'ladipoe',
        'Vector' => 'vector',
        'Asa' => 'asa',
        'Demmie Vee' => 'demmie-vee',
        'King Perryy' => 'king-perryy',
        'Skiibii' => 'skiibii',
        'Timaya' => 'timaya',
        'Slimcase' => 'slimcase',
        'Ice Prince' => 'ice-prince',
        'Peruzzi' => 'peruzzi',
        'Yung6ix' => 'yung6ix',
        'Diamond Platnumz' => 'diamond-platnumz',
    ];
?>

<div class="ts-sidebar-content">
    <section class="ts-aside-section">
        <h2 class="ts-sidebar-heading">Explore TrendySongz</h2>

        <ul>
            <li>
                <a href="<?php echo e(route('pages.musics', 'naija')); ?>">
                    Naija Music
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('pages.musics', 'ghana')); ?>">
                    Ghana Music
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('pages.videos_all')); ?>">
                    Latest Videos
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('pages.album')); ?>">
                    Albums &amp; EPs
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('pages.djmix')); ?>">
                    DJ Mixes
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('pages.celebrity_news')); ?>">
                    Music News
                </a>
            </li>
        </ul>
    </section>

    <section class="ts-aside-section">
        <h2 class="ts-sidebar-heading">Popular Artistes</h2>

        <ul class="ts-aside-artist-list">
            <?php $__currentLoopData = $popularArtistes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(route('pages.artists_details', $slug)); ?>">
                        <?php echo e($name); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </section>

    <section class="ts-aside-section">
        <h2 class="ts-sidebar-heading">Star Artistes</h2>

        <ul class="ts-aside-artist-list">
            <?php $__currentLoopData = $starArtistes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(route('pages.artists_details', $slug)); ?>">
                        <?php echo e($name); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </section>
</div><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/layouts/aside.blade.php ENDPATH**/ ?>