

<?php
    $djName = $dj->dj_name ?: 'TrendySongz DJ';
    $mixTitle = $dj->mix_title ?: 'DJ Mixtape';
    $title = $djName . ' - ' . $mixTitle;

    $canonicalSlug = $dj->slug
        ?: \Illuminate\Support\Str::slug($title);

    $canonicalUrl = route('pages.djmix_detail', [
        $dj->id,
        $canonicalSlug,
    ]);

    $description = \Illuminate\Support\Str::limit(
        trim(strip_tags(($dj->description1 ?: $dj->details) ?: $title)),
        160
    );

    $postedDate = $dj->created_at
        ? \Illuminate\Support\Carbon::parse($dj->created_at)
        : null;

    $coverUrl = $dj->cover_url
        ? asset('images/dj/' . ltrim($dj->cover_url, '/'))
        : null;

        $audioFilename = trim((string) ($dj->track_url ?? ''));
    $audioPath = 'media/djmixs/'.$audioFilename;

    $audioUrl = $audioFilename !== ''
        && basename($audioFilename) === $audioFilename
        && ! str_contains($audioFilename, '\\')
        && \Illuminate\Support\Facades\Storage::disk('public')
            ->exists($audioPath)
            ? asset('storage/'.$audioPath)
            : null;    
?>

<?php $__env->startSection('title', 'Download Mix: ' . $title . ' Mix'); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($description); ?>">
    <meta name="keywords" content="<?php echo e($title); ?> mix, <?php echo e($title); ?>, download <?php echo e($title); ?>, latest DJ mix">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="music.song">
    <meta property="og:site_name" content="TrendySongz">
    <meta property="og:title" content="<?php echo e($title); ?>">
    <meta property="og:description" content="<?php echo e($description); ?>">
    <meta property="og:url" content="<?php echo e($canonicalUrl); ?>">

    <?php if($coverUrl): ?>
        <meta property="og:image" content="<?php echo e($coverUrl); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="@TrendySongz_">
    <meta name="twitter:title" content="<?php echo e($title); ?>">
    <meta name="twitter:description" content="<?php echo e($description); ?>">

    <?php if($coverUrl): ?>
        <meta name="twitter:image" content="<?php echo e($coverUrl); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article class="ts-music-detail">
        <header class="ts-music-header">
            <h1 class="ts-music-title">
                <?php echo e($title); ?> | Download DJ Mix
            </h1>

            <div class="ts-music-meta">
                <span>
                    Posted By: <?php echo e($dj->posted_user ?: 'TrendySongz'); ?>

                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                </span>

                <?php if($postedDate): ?>
                    <span class="ts-meta-separator">|</span>

                    <time
                        class="ts-music-date"
                        datetime="<?php echo e($postedDate->toDateString()); ?>"
                    >
                        <?php echo e($postedDate->format('M j, Y')); ?>

                    </time>
                <?php endif; ?>
            </div>
        </header>

        <section class="ts-music-details-card">
            <div class="ts-music-info-bar">
                <div class="ts-info-item">
                    <span class="ts-info-label">DJ</span>

                    <span class="ts-info-value" title="<?php echo e($djName); ?>">
                        <?php echo e($djName); ?>

                    </span>
                </div>

                <?php if($dj->released_year): ?>
                    <div class="ts-info-item">
                        <span class="ts-info-label">Released</span>

                        <span class="ts-info-value">
                            <?php echo e($dj->released_year); ?>

                        </span>
                    </div>
                <?php endif; ?>

                <div class="ts-info-item">
                    <span class="ts-info-label">Category</span>

                    <span class="ts-info-value">
                        <a href="<?php echo e(route('pages.djmix')); ?>">DJ Mix</a>
                    </span>
                </div>

                <?php if(filled($dj->duration ?? null)): ?>
                    <div class="ts-info-item">
                        <span class="ts-info-label">Duration</span>

                        <span class="ts-info-value">
                            <?php echo e($dj->duration); ?>

                        </span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="ts-music-body">
                <div class="ts-music-cover">
                    <?php echo $__env->make('pages.partials.cover', [
                        'src' => $dj->cover_url,
                        'folder' => 'dj/',
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                <div class="ts-music-content">
                    <h2 class="ts-song-artist"><?php echo e($djName); ?></h2>

                    <div class="ts-song-title-row">
                        <h3 class="ts-song-title"><?php echo e($mixTitle); ?></h3>
                    </div>

                    <div class="ts-audio-box">
                        <?php if($audioUrl): ?>
                            <button
                                type="button"
                                class="ts-main-play"
                                id="ts-djmix-play"
                                aria-label="Play <?php echo e($title); ?>"
                            >
                                <i class="fa fa-play" aria-hidden="true"></i>
                            </button>

                            <audio
                                id="ts-djmix-audio"
                                src="<?php echo e($audioUrl); ?>"
                                preload="none"
                            ></audio>
                        <?php else: ?>
                            <button
                                type="button"
                                class="ts-main-play"
                                aria-label="Audio unavailable"
                                disabled
                            >
                                <i class="fa fa-play" aria-hidden="true"></i>
                            </button>
                        <?php endif; ?>

                        <span class="ts-audio-heading">
                            Listen to <?php echo e($title); ?> Here
                        </span>
                    </div>

                    <?php if($audioUrl): ?>
                        <a
                            class="ts-download-button"
                            href="<?php echo e($audioUrl); ?>"
                            download="<?php echo e($audioFilename); ?>"
                        >
                            <i class="fa fa-download" aria-hidden="true"></i>
                            Download <?php echo e($title); ?>

                        </a>
                    <?php else: ?>
                        <button
                            type="button"
                            class="ts-download-button"
                            disabled
                        >
                            <i class="fa fa-download" aria-hidden="true"></i>
                            Download <?php echo e($title); ?>

                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <?php if(filled($dj->description1) || filled($dj->description2)): ?>
            <section class="ts-about-song">
                <div class="ts-about-song-inner">
                    <h2 class="ts-about-heading">About This DJ Mix</h2>

                    <div class="ts-about-text">
                        <?php if(filled($dj->description1)): ?>
                            <p><?php echo nl2br(e(strip_tags($dj->description1))); ?></p>
                        <?php endif; ?>

                        <?php if(filled($dj->description2)): ?>
                            <p><?php echo nl2br(e(strip_tags($dj->description2))); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <?php if($djOtherMixes->isNotEmpty()): ?>
            <section class="ts-djmix-section">
                <header class="ts-section-heading">
                    <h2>Other Mixtapes by <?php echo e($djName); ?></h2>
                </header>

                <div class="ts-djmix-list">
                    <?php $__currentLoopData = $djOtherMixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $relatedDjName = $mix->dj_name ?: $djName;
                            $relatedTitle = $mix->mix_title ?: 'DJ Mixtape';

                            $relatedSlug = $mix->slug
                                ?: \Illuminate\Support\Str::slug(
                                    $relatedDjName . ' ' . $relatedTitle
                                );
                        ?>

                        <a
                            class="ts-djmix-card"
                            href="<?php echo e(route('pages.djmix_detail', [
                                $mix->id,
                                $relatedSlug,
                            ])); ?>"
                        >
                            <span class="ts-djmix-cover">
                                <?php echo $__env->make('pages.partials.cover', [
                                    'src' => $mix->cover_url,
                                    'folder' => 'dj',
                                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                                <span class="ts-djmix-play" aria-hidden="true">
                                    <i class="fa fa-play"></i>
                                </span>
                            </span>

                            <span class="ts-djmix-info">
                                <span class="ts-djmix-label">DJ MIXTAPE</span>

                                <span class="ts-djmix-dj">
                                    <?php echo e($relatedDjName); ?>

                                </span>

                                <span class="ts-djmix-title">
                                    <?php echo e($relatedTitle); ?>

                                </span>

                                <?php if(filled($mix->duration ?? null)): ?>
                                    <span class="ts-djmix-duration">
                                        <i class="fa fa-clock-o" aria-hidden="true"></i>
                                        <?php echo e($mix->duration); ?>

                                    </span>
                                <?php endif; ?>

                                <span class="ts-djmix-action">
                                    View mixtape
                                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                </span>
                            </span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if($otherDjMixes->isNotEmpty()): ?>
            <section class="ts-djmix-section">
                <header class="ts-section-heading">
                    <h2>Mixtapes by Other DJs</h2>
                </header>

                <div class="ts-djmix-list">
                    <?php $__currentLoopData = $otherDjMixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $relatedDjName = $mix->dj_name ?: 'TrendySongz DJ';
                            $relatedTitle = $mix->mix_title ?: 'DJ Mixtape';

                            $relatedSlug = $mix->slug
                                ?: \Illuminate\Support\Str::slug(
                                    $relatedDjName . ' ' . $relatedTitle
                                );
                        ?>

                        <a
                            class="ts-djmix-card"
                            href="<?php echo e(route('pages.djmix_detail', [
                                $mix->id,
                                $relatedSlug,
                            ])); ?>"
                        >
                            <span class="ts-djmix-cover">
                                <?php echo $__env->make('pages.partials.cover', [
                                    'src' => $mix->cover_url,
                                    'folder' => 'dj',
                                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                                <span class="ts-djmix-play" aria-hidden="true">
                                    <i class="fa fa-play"></i>
                                </span>
                            </span>

                            <span class="ts-djmix-info">
                                <span class="ts-djmix-label">DJ MIXTAPE</span>

                                <span class="ts-djmix-dj">
                                    <?php echo e($relatedDjName); ?>

                                </span>

                                <span class="ts-djmix-title">
                                    <?php echo e($relatedTitle); ?>

                                </span>

                                <?php if(filled($mix->duration ?? null)): ?>
                                    <span class="ts-djmix-duration">
                                        <i class="fa fa-clock-o" aria-hidden="true"></i>
                                        <?php echo e($mix->duration); ?>

                                    </span>
                                <?php endif; ?>

                                <span class="ts-djmix-action">
                                    View mixtape
                                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                </span>
                            </span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
    </article>


    <?php if($audioUrl): ?>
        <script>
            const djAudio = document.getElementById('ts-djmix-audio');
            const djPlayButton = document.getElementById('ts-djmix-play');
            const djPlayIcon = djPlayButton.querySelector('i');

            djPlayButton.addEventListener('click', function () {
                if (djAudio.paused) {
                    djAudio.play();
                } else {
                    djAudio.pause();
                }
            });

            djAudio.addEventListener('play', function () {
                djPlayIcon.classList.replace('fa-play', 'fa-pause');
                djPlayButton.setAttribute(
                    'aria-label',
                    'Pause DJ mix'
                );
            });

            function showDjPlayIcon() {
                djPlayIcon.classList.replace('fa-pause', 'fa-play');
                djPlayButton.setAttribute(
                    'aria-label',
                    'Play DJ mix'
                );
            }

            djAudio.addEventListener('pause', showDjPlayIcon);
            djAudio.addEventListener('ended', showDjPlayIcon);
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/djmix_detail.blade.php ENDPATH**/ ?>