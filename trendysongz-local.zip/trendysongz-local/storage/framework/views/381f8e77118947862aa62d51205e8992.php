

<?php
    $artistName = $artist->ArtistsName
        ?: $artist->Stage_Name
        ?: 'Artist';

    $artistSlug = \Illuminate\Support\Str::slug($artistName);

    $canonicalUrl = route('pages.artists_details', $artistSlug);

    $pageTitle = 'Download Latest ' . $artistName
        . ' Songs, Music, Albums, Biography, Profile, All Music, Videos - TrendySongz';

    $metaDescription = 'Download ' . $artistName
        . ' Songs, Download Latest ' . $artistName
        . ' Songs, Download Latest ' . $artistName
        . ' Album, Download Latest ' . $artistName
        . ' Music, Read ' . $artistName
        . ' Biography and view their full Discography on TrendySongz';

    $profileImage = $artist->ProfilePic
        ? asset('images/' . ltrim($artist->ProfilePic, '/'))
        : null;
?>

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($metaDescription); ?>">
    <meta
        name="keywords"
        content="<?php echo e($artistName); ?> songs, download <?php echo e($artistName); ?> songs, download latest <?php echo e($artistName); ?> songs, download <?php echo e($artistName); ?> albums, <?php echo e($artistName); ?> biography"
    >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="profile">
    <meta property="og:site_name" content="TrendySongz">
    <meta property="og:title" content="<?php echo e($pageTitle); ?>">
    <meta property="og:description" content="<?php echo e($metaDescription); ?>">
    <meta property="og:url" content="<?php echo e($canonicalUrl); ?>">

    <?php if($profileImage): ?>
        <meta property="og:image" content="<?php echo e($profileImage); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="<?php echo e($artistName); ?>">
    <meta name="twitter:description" content="<?php echo e($metaDescription); ?>">

    <?php if($profileImage): ?>
        <meta name="twitter:image" content="<?php echo e($profileImage); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-artist-detail">
        <h1 class="ts-artist-page-title">
            Download Latest <?php echo e($artistName); ?> Songs, Albums, Biography, All Music, and Videos on TrendySongz
        </h1>

            <time class="post-date" datetime="<?php echo e(now()->toDateString()); ?>" >
                <?php echo e(now()->format('M d, Y')); ?>

            </time>

        <section class="ts-artist-section ts-artist-profile-section">
            <div class="ts-artist-profile-card">
                <div class="ts-artist-profile-image">
                    <?php if($profileImage): ?>
                        <img src="<?php echo e($profileImage); ?>" alt="<?php echo e($artistName); ?>">
                    <?php else: ?>
                        <div class="ts-artist-profile-placeholder">
                            <i class="fa fa-user" aria-hidden="true"></i>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="ts-artist-profile-info">
                    <?php if($artist->Fullname): ?>
                        <div class="ts-artist-profile-row">
                            <span class="ts-artist-profile-label">Full Name</span>
                            <span class="ts-artist-profile-value">
                                <?php echo e($artist->Fullname); ?>

                            </span>
                        </div>
                    <?php endif; ?>

                    <?php if($artist->Stage_Name): ?>
                        <div class="ts-artist-profile-row">
                            <span class="ts-artist-profile-label">Stage Name</span>
                            <span class="ts-artist-profile-value">
                                <?php echo e($artist->Stage_Name); ?>

                            </span>
                        </div>
                    <?php endif; ?>

                    

                    <?php if($artist->Genres): ?>
                        <div class="ts-artist-profile-row">
                            <span class="ts-artist-profile-label">Genre</span>
                            <span class="ts-artist-profile-value">
                                <?php echo e($artist->Genres); ?>

                            </span>
                        </div>
                    <?php endif; ?>

                    <?php if($artist->RecordLabel): ?>
                        <div class="ts-artist-profile-row">
                            <span class="ts-artist-profile-label">Record Label</span>
                            <span class="ts-artist-profile-value">
                                <?php echo e($artist->RecordLabel); ?>

                            </span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <?php if(filled($artist->ArtistsProfile)): ?>
            <section class="ts-artist-section">
                <header class="ts-artist-section-heading">
                    <h2><?php echo e($artistName); ?> Biography</h2>
                </header>

                <div class="ts-artist-about-text">
                    <?php echo nl2br(e(strip_tags($artist->Place_Birth))); ?>

                </div>
            </section>
        <?php endif; ?>

        <section class="ts-artist-section">
            <header class="ts-artist-section-heading">
                <h2><?php echo e($artistName); ?> Albums and EPs</h2>
            </header>

            <div class="ts-artist-albums">
                <?php $__empty_1 = true; $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $tracks = $albumTracks->get($album->id, collect());
                        $panelId = 'artist-album-tracks-' . $album->id;
                    ?>

                    <div class="ts-artist-album">
                        <button
                            type="button"
                            class="ts-artist-album-header"
                            aria-expanded="false"
                            aria-controls="<?php echo e($panelId); ?>"
                        >
                            <span class="ts-artist-album-cover">
                                <?php echo $__env->make('pages.partials.cover', [
                                    'src' => $album->cover_url,
                                    'folder' => '',
                                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </span>

                            <span class="ts-artist-album-header-info">
                                <span class="ts-artist-album-title">
                                    <?php echo e($album->title); ?>

                                </span>

                                <span class="ts-artist-album-meta">
                                    <span class="ts-artist-album-meta-item">
                                        <span class="ts-artist-album-meta-label">
                                            Tracks
                                        </span>
                                        <span class="ts-artist-album-meta-value">
                                            <?php echo e($tracks->count()); ?>

                                        </span>
                                    </span>

                                    <?php if($album->released_year): ?>
                                        <span class="ts-artist-album-meta-item">
                                            <span class="ts-artist-album-meta-label">
                                                Released
                                            </span>
                                            <span class="ts-artist-album-meta-value">
                                                <?php echo e($album->released_year); ?>

                                            </span>
                                        </span>
                                    <?php endif; ?>
                                </span>
                            </span>

                            <span class="ts-artist-album-toggle" aria-hidden="true">
                                <i class="fa fa-chevron-down"></i>
                            </span>
                        </button>

                        <div
                            id="<?php echo e($panelId); ?>"
                            class="ts-artist-album-tracks"
                        >
                            <?php $__empty_2 = true; $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <a
                                    class="ts-artist-track"
                                    href="<?php echo e(route('pages.musics_detail', [
                                        $track->id,
                                        \Illuminate\Support\Str::slug(
                                            $artistName . ' ' . $track->TrackTitle
                                        ),
                                    ])); ?>"
                                >
                                    <span class="ts-artist-track-number">
                                        <?php echo e($track->track_number ?: $loop->iteration); ?>

                                    </span>

                                    <span class="ts-artist-track-info">
                                        <span class="ts-artist-track-title-row">
                                            <span class="ts-artist-track-title">
                                                <?php echo e($track->TrackTitle); ?>

                                            </span>

                                            <?php if($track->Featuring): ?>
                                                <span class="ts-artist-track-featuring">
                                                    feat. <?php echo e($track->Featuring); ?>

                                                </span>
                                            <?php endif; ?>
                                        </span>

                                        <?php if($track->producedby): ?>
                                            <span class="ts-artist-track-credit">
                                                Produced by <?php echo e($track->producedby); ?>

                                            </span>
                                        <?php endif; ?>
                                    </span>

                                    <span class="ts-artist-track-arrow" aria-hidden="true">
                                        <i class="fa fa-arrow-right"></i>
                                    </span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <p class="ts-artist-no-tracks">
                                    No tracks have been added to this album yet.
                                </p>
                            <?php endif; ?>

                            <a
                                href="<?php echo e(route('pages.album_details', [
                                    $album->id,
                                    \Illuminate\Support\Str::slug(
                                        $artistName . ' ' . $album->title
                                    ),
                                ])); ?>"
                            >
                                View <?php echo e($album->title); ?> album
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No albums found for <?php echo e($artistName); ?>.</p>
                <?php endif; ?>
            </div>
        </section>

        <section class="ts-artist-section">
            <header class="ts-artist-section-heading">
                <h2><?php echo e($artistName); ?> Singles</h2>
            </header>

            <div class="ts-artist-singles">
                <?php $__empty_1 = true; $__currentLoopData = $singles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a
                        class="ts-artist-track ts-artist-single"
                        href="<?php echo e(route('pages.musics_detail', [
                            $track->id,
                            \Illuminate\Support\Str::slug(
                                $artistName . ' ' . $track->TrackTitle
                            ),
                        ])); ?>"
                    >
                        <span class="ts-artist-track-number">
                            <?php echo e($loop->iteration); ?>

                        </span>

                        <span class="ts-artist-track-info">
                            <span class="ts-artist-track-title-row">
                                <span class="ts-artist-track-title">
                                    <?php echo e($track->TrackTitle); ?>

                                </span>

                                <?php if($track->Featuring): ?>
                                    <span class="ts-artist-track-featuring">
                                        feat. <?php echo e($track->Featuring); ?>

                                    </span>
                                <?php endif; ?>
                            </span>

                            <?php if($track->producedby): ?>
                                <span class="ts-artist-track-credit">
                                    Produced by <?php echo e($track->producedby); ?>

                                </span>
                            <?php endif; ?>
                        </span>

                        <span class="ts-artist-track-arrow" aria-hidden="true">
                            <i class="fa fa-arrow-right"></i>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No singles found for <?php echo e($artistName); ?>.</p>
                <?php endif; ?>
            </div>
        </section>

        <?php if($videos->isNotEmpty()): ?>
            <section class="ts-artist-section">
                <header class="ts-artist-section-heading">
                    <h2><?php echo e($artistName); ?> Videos</h2>
                </header>

                <div class="ts-artist-info-list">
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ts-artist-info-item">
                            <div class="ts-artist-info-item-text">
                                <div class="ts-artist-info-item-title">
                                    <a href="<?php echo e(route('pages.videos_detail', [
                                        $video->id,
                                        \Illuminate\Support\Str::slug(
                                            $artistName . ' ' . $video->TrackTitle
                                        ),
                                    ])); ?>">
                                        <?php echo e($artistName); ?> - <?php echo e($video->TrackTitle); ?>

                                    </a>
                                </div>

                                <?php if($video->directedby): ?>
                                    <div class="ts-artist-info-text">
                                        Directed by <?php echo e($video->directedby); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if($featuredSongs->isNotEmpty()): ?>
            <section class="ts-artist-section">
                <header class="ts-artist-section-heading">
                    <h2>Songs Featuring <?php echo e($artistName); ?></h2>
                </header>

                <div class="ts-artist-info-list">
                    <?php $__currentLoopData = $featuredSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ts-artist-info-item">
                            <div class="ts-artist-info-item-text">
                                <div class="ts-artist-info-item-title">
                                    <a href="<?php echo e(route('pages.musics_detail', [
                                        $track->id,
                                        \Illuminate\Support\Str::slug(
                                            ($track->primary_artist ?: 'Artist')
                                            . ' '
                                            . $track->TrackTitle
                                        ),
                                    ])); ?>">
                                        <?php echo e($track->primary_artist ?: 'Artist'); ?>

                                        - <?php echo e($track->TrackTitle); ?>

                                    </a>
                                </div>

                                <div class="ts-artist-info-text">
                                    feat. <?php echo e($track->Featuring); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
    </div>

    <script>
        document.addEventListener('click', function (event) {
            const button = event.target.closest(
                '.ts-artist-album-header'
            );

            if (!button) {
                return;
            }

            const album = button.closest('.ts-artist-album');

            if (!album) {
                return;
            }

            const isOpen = album.classList.toggle('is-open');

            button.setAttribute(
                'aria-expanded',
                isOpen ? 'true' : 'false'
            );
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/artists_detail.blade.php ENDPATH**/ ?>