<?php $__env->startSection('title', 'Listings'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Audio and video listings</h1>

    <div class="admin-panel">
        <form
            class="admin-toolbar"
            method="GET"
            action="<?php echo e(route('admin.listings.index')); ?>"
        >
            <input
                type="search"
                name="q"
                value="<?php echo e($search); ?>"
                placeholder="Title or artist"
                aria-label="Search listings"
            >

            <select name="type" aria-label="Listing type">
                <option value="">All types</option>
                <option value="audio" <?php if($type === 'audio'): echo 'selected'; endif; ?>>Audio</option>
                <option value="video" <?php if($type === 'video'): echo 'selected'; endif; ?>>Video</option>
            </select>

            <button class="admin-button" type="submit">Filter</button>

            <a class="admin-button" href="<?php echo e(route('admin.listings.create')); ?>">
                Add listing
            </a>
        </form>

        <div class="admin-table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Artist</th>
                        <th>Type</th>
                        <th>Country</th>
                        <th>Published</th>
                        <th>Posted</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->TrackTitle); ?></td>
                            <td><?php echo e($row->ArtistsName); ?></td>
                            <td><?php echo e($row->ListingType); ?></td>
                            <td><?php echo e($row->country_id); ?></td>
                            <td><?php echo e($row->IsPublished); ?></td>
                            <td><?php echo e($row->created_at); ?></td>

                            <td>
                                <?php if(
                                    (int) auth()->user()->roleid === 1
                                    || (int) $row->user_id === (int) auth()->id()
                                ): ?>
                                    <div class="admin-actions">
                                        <a
                                            class="admin-button admin-button-secondary"
                                            href="<?php echo e(route('admin.listings.edit', $row->id)); ?>"
                                        >
                                            Edit
                                        </a>

                                        <form
                                            method="POST"
                                            action="<?php echo e(route('admin.listings.destroy', $row->id)); ?>"
                                            onsubmit="return confirm('Delete this listing and its locally uploaded files?')"
                                        >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button class="admin-danger" type="submit">
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8">No listings found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
    </div>
        <div class="ts-list-pagination">
            <?php echo e($rows->links('vendor.pagination.trendysongz')); ?>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/listings/index.blade.php ENDPATH**/ ?>