<?php $__env->startSection('title', 'Add artiste'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Add artiste</h1>

    <?php echo $__env->make('admin.artists.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/artists/create.blade.php ENDPATH**/ ?>