<?php $__env->startSection('title', 'Artists Profiles & Full Album Downloads'); ?>

<?php $__env->startSection('meta'); ?>
    <meta
        name="description"
        content="Download all the Latest Music, Videos and Albums from your favorite Artists - Download all Latest Music By Nigerian Artistes, Ghana and African Artistes"
    >
    <meta
        name="keywords"
        content="download latest Nigerian Artistes Music, download music album, latests songs, 2Baba, tekno, tiwa savage, burna boy, zlatan, mi, ycee, flavour, phyno, rema, olamide, d prince, akon, timaya, spinall, neptune, cuppy, kizz daniel, naija musics, nigerian songs"
    >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e(url('/artists')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-artists-page">
        <header class="ts-artists-header">
            <div class="ts-section-heading">
                <div>
                    <h1>Artists Profiles &amp; Full Album Downloads</h1>

                    <p class="ts-artists-intro">
                        Download latest music from Nigerian artists,
                        Ghanaian artists and African musicians.
                    </p>
                </div>
            </div>

           
            <time class="ts-artists-date" datetime="<?php echo e(now()->toDateString()); ?>">
                <?php echo e(now()->format('M d, Y')); ?>

            </time>
        </header>

        <section class="ts-artists-section">
            <header class="ts-section-heading">
                <h2>Popular Artists</h2>
            </header>

            <div class="ts-popular-grid">
                <?php $__empty_1 = true; $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $artistName = $row->ArtistsName
                            ?: $row->Stage_Name
                            ?: 'Unknown Artist';
                    ?>

                    <a
                        class="ts-popular-card"
                        href="<?php echo e(route(
                            'pages.artists_details',
                            \Illuminate\Support\Str::slug($artistName)
                        )); ?>"
                    >
                        <span class="ts-popular-image">
                            <?php if($row->ProfilePic): ?>
                                <img
                                    src="<?php echo e(asset('images/' . ltrim($row->ProfilePic, '/'))); ?>"
                                    alt="<?php echo e($artistName); ?>"
                                    loading="lazy"
                                >
                            <?php else: ?>
                                <span class="ts-artist-placeholder">
                                    <i class="fa fa-user" aria-hidden="true"></i>
                                </span>
                            <?php endif; ?>
                        </span>

                        <span class="ts-popular-info">
                            <span class="ts-artist-label">POPULAR ARTIST</span>

                            <span class="ts-popular-name">
                                <?php echo e($artistName); ?>

                            </span>

                            <?php if($row->RecordLabel): ?>
                                <span class="ts-artist-record-label">
                                    <?php echo e($row->RecordLabel); ?>

                                </span>
                            <?php endif; ?>

                            <span class="ts-artist-stats">
                                <span>Albums <?php echo e($row->album_count); ?></span>
                                <span>Singles <?php echo e($row->single_count); ?></span>
                            </span>                            

                            <span class="ts-artist-view">View artist →</span>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No popular artists found.</p>
                <?php endif; ?>
            </div>
        </section>

        <?php echo $__env->make('pages.partials.artist-country-section', [
            'section' => 'naija',
            'heading' => 'Nigerian Artists',
            'rows' => $naija,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('pages.partials.artist-country-section', [
            'section' => 'ghana',
            'heading' => 'Ghanaian Artists',
            'rows' => $ghana,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('pages.partials.artist-country-section', [
            'section' => 'african',
            'heading' => 'African Artists',
            'rows' => $african,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <script>
        document.addEventListener('click', async function (event) {
            const link = event.target.closest(
                '.ts-artists-section[data-artist-section] ' +
                '.ts-artist-pagination a'
            );

            if (!link) {
                return;
            }

            const section = link.closest('[data-artist-section]');

            if (!section) {
                return;
            }

            event.preventDefault();

            const url = new URL(link.href);
            url.searchParams.set(
                'section',
                section.dataset.artistSection
            );

            try {
                section.setAttribute('aria-busy', 'true');

                const response = await fetch(url.toString(), {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'text/html',
                    },
                });

                if (!response.ok) {
                    throw new Error('Unable to load artist page.');
                }

                const markup = await response.text();
                const documentFragment = new DOMParser()
                    .parseFromString(markup, 'text/html');

                const replacement = documentFragment.querySelector(
                    '.ts-artists-section[data-artist-section]'
                );

                if (!replacement) {
                    throw new Error('Artist section was not returned.');
                }

                section.replaceWith(replacement);
                window.history.pushState({}, '', url.toString());

                replacement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start',
                });
            } catch (error) {
                window.location.assign(url.toString());
            } finally {
                section.removeAttribute('aria-busy');
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/artists.blade.php ENDPATH**/ ?>