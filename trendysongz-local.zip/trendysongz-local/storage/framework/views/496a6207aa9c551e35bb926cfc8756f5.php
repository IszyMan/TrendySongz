

<?php $__env->startSection('title', 'DJs'); ?>

<?php $__env->startSection('content'); ?>
    <h1>DJs</h1>

    <div class="admin-panel">
        <form
            class="admin-toolbar"
            method="GET"
            action="<?php echo e(route('admin.djs.index')); ?>"
        >
            <input
                type="search"
                name="q"
                value="<?php echo e($search); ?>"
                placeholder="Search DJs"
                aria-label="Search DJs"
            >

            <button class="admin-button" type="submit">
                Search
            </button>

            <a
                class="admin-button"
                href="<?php echo e(route('admin.djs.create')); ?>"
            >
                Add DJ
            </a>
        </form>

        <div class="admin-table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>DJ name</th>
                        <th>Full name</th>
                        <th>Country</th>
                        <th>Published</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $djs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($dj->id); ?></td>
                            <td><?php echo e($dj->dj_name); ?></td>
                            <td><?php echo e($dj->fullname); ?></td>
                            <td><?php echo e($dj->country_id); ?></td>
                            <td><?php echo e($dj->IsPublished); ?></td>

                            <td>
                                <?php if(
                                    (int) auth()->user()->roleid === 1
                                    || (int) $dj->user_id
                                        === (int) auth()->id()
                                ): ?>
                                    <div class="admin-actions">
                                        <a
                                            class="admin-button admin-button-secondary"
                                            href="<?php echo e(route(
                                                'admin.djs.edit',
                                                $dj->id
                                            )); ?>"
                                        >
                                            Edit
                                        </a>

                                        <form
                                            method="POST"
                                            action="<?php echo e(route(
                                                'admin.djs.destroy',
                                                $dj->id
                                            )); ?>"
                                            onsubmit="return confirm('Delete this DJ?')"
                                        >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button
                                                class="admin-danger"
                                                type="submit"
                                            >
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">
                                No DJs found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="ts-list-pagination">
            <?php echo e($djs->links('vendor.pagination.trendysongz')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/djs/index.blade.php ENDPATH**/ ?>