<?php
    $videoTitle = trim(
        ($artist->ArtistsName ?: 'Unknown Artist')
        . ' - '
        . $artist->TrackTitle
    );

    $description = trim(strip_tags(
        $artist->TrackInfo ?: ($artist->introduction ?: '')
    ));

    $metaDescription = trim(
        'Download ' . $videoTitle . '. ' . $description
    );

    $canonicalUrl = route('pages.videos_detail', [
        $artist->id,
        \Illuminate\Support\Str::slug($videoTitle),
    ]);

    $coverUrl = $artist->CoverUrl
        ? asset('images/' . ltrim($artist->CoverUrl, '/'))
        : null;
?>

<?php $__env->startSection('title', $videoTitle . ' | Download Video MP4 » Trendysongz'); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($metaDescription); ?>">
    <meta name="keywords" content="<?php echo e($videoTitle); ?>, <?php echo e($videoTitle); ?> video, download <?php echo e($videoTitle); ?>, download <?php echo e($videoTitle); ?> mp4, <?php echo e($videoTitle); ?> video download">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="video.other">
    <meta property="og:site_name" content="TrendySongz">
    <meta property="og:title" content="<?php echo e($videoTitle); ?>">
    <meta property="og:description" content="<?php echo e($metaDescription); ?>">
    <meta property="og:url" content="<?php echo e($canonicalUrl); ?>">

    <?php if($coverUrl): ?>
        <meta property="og:image" content="<?php echo e($coverUrl); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="@Trendysongz">
    <meta name="twitter:title" content="<?php echo e($videoTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($metaDescription); ?>">

    <?php if($coverUrl): ?>
        <meta name="twitter:image" content="<?php echo e($coverUrl); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-video-detail">
        <header class="ts-video-detail-header">
            <h1 class="ts-video-detail-title">
                <?php echo e($videoTitle); ?>


                <?php if($artist->Featuring): ?>
                    <span class="ts-video-detail-featuring">
                        feat. <?php echo e($artist->Featuring); ?>

                    </span>
                <?php endif; ?>
            </h1>

            <div class="ts-video-detail-post-meta">
                <a
                    class="ts-video-detail-posted-by"
                    href="<?php echo e(route(
                        'pages.videos_posted_by',
                        \Illuminate\Support\Str::slug($artist->postedby)
                    )); ?>"
                >
                    Posted by:
                    <strong><?php echo e($artist->postedby); ?></strong>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                </a>

                <?php if($artist->created_at): ?>
                    <span class="ts-video-detail-meta-separator">•</span>

                    <time
                        class="ts-video-detail-date"
                        datetime="<?php echo e(\Illuminate\Support\Carbon::parse($artist->created_at)->toDateString()); ?>"
                    >
                        <?php echo e(\Illuminate\Support\Carbon::parse($artist->created_at)->format('M d, Y')); ?>

                    </time>
                <?php endif; ?>
            </div>
        </header>

        <div class="ts-video-detail-info-bar">
            <div class="ts-video-detail-info-item">
                <span class="ts-video-detail-info-label">Director</span>
                <span class="ts-video-detail-info-value">
                    <?php echo e($artist->directedby ?: '—'); ?>

                </span>
            </div>

            <div class="ts-video-detail-info-item">
                <span class="ts-video-detail-info-label">Released</span>
                <span class="ts-video-detail-info-value">
                    <a href="<?php echo e(route('pages.videos_released_year', $artist->YearOfRelease)); ?>">
                        <?php echo e($artist->YearOfRelease); ?>

                    </a>
                </span>
            </div>

            <div class="ts-video-detail-info-item">
                <span class="ts-video-detail-info-label">Country</span>
                <span class="ts-video-detail-info-value">
                    <?php echo e($artist->country_id ? ucfirst($artist->country_id) : '—'); ?>

                </span>
            </div>

            <div class="ts-video-detail-info-item">
                <span class="ts-video-detail-info-label">Category</span>
                <span class="ts-video-detail-info-value">
                    <a href="<?php echo e(route('pages.videos_all')); ?>">
                        <?php echo e((int) $artist->is_video_comedy === 1 ? 'Comedy Video' : 'Music Video'); ?>

                    </a>
                </span>
            </div>
        </div>

        <section class="ts-video-detail-player-section">
            <div class="ts-video-detail-player">
                <?php if($artist->TrackUrl): ?>
                    <video
                        controls
                        preload="none"
                        <?php if($coverUrl): ?> poster="<?php echo e($coverUrl); ?>" <?php endif; ?>
                    >
                        <source
                            src="<?php echo e('https://cdn.trendysongz.com/video/' . ltrim($artist->TrackUrl, '/')); ?>"
                            type="video/mp4"
                        >
                        Your browser does not support video playback.
                    </video>
                <?php elseif($coverUrl): ?>
                    <img
                        class="ts-detail-cover"
                        src="<?php echo e($coverUrl); ?>"
                        alt="<?php echo e($videoTitle); ?>"
                    >
                <?php endif; ?>
            </div>

            <?php if($artist->TrackUrl): ?>
                <div class="ts-video-detail-download-wrap">
                    <a
                        class="ts-video-detail-download"
                        href="<?php echo e('https://cdn.trendysongz.com/video/' . ltrim($artist->TrackUrl, '/')); ?>"
                        download
                    >
                        <i class="fa fa-download" aria-hidden="true"></i>
                        Download <?php echo e($artist->TrackTitle); ?> MP4
                    </a>
                </div>
            <?php else: ?>
                <p class="ts-video-detail-notice">
                    Video file awaiting restoration.
                </p>
            <?php endif; ?>
        </section>

        <?php if($artist->introduction): ?>
            <section class="ts-video-detail-section ts-video-detail-about">
                <h2 class="ts-video-detail-section-heading">
                    About this video
                </h2>

                <div class="ts-video-detail-about-text">
                    <?php echo $artist->introduction; ?>

                </div>
            </section>
        <?php endif; ?>

        <?php if($artist->TrackInfo || $artist->trackinfo1): ?>
            <section class="ts-video-detail-section ts-video-detail-information">
                <h2 class="ts-video-detail-section-heading">
                    Video information
                </h2>

                <?php if($artist->TrackInfo): ?>
                    <div class="ts-video-detail-info-text">
                        <?php echo $artist->TrackInfo; ?>

                    </div>
                <?php endif; ?>

                <?php if($artist->trackinfo1): ?>
                    <div class="ts-video-detail-info-text">
                        <?php echo $artist->trackinfo1; ?>

                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <?php if($additional_link): ?>
            <section class="ts-video-detail-audio-link">
                <span>Also available:</span>

                <a
                    href="<?php echo e(route('pages.musics_detail', [
                        $additional_link->id,
                        \Illuminate\Support\Str::slug(
                            trim(
                                ($additional_link->ArtistsName ?? '')
                                . ' '
                                . ($additional_link->TrackTitle ?? '')
                            )
                        ),
                    ])); ?>"
                >
                    Download audio:
                    <?php echo e($additional_link->ArtistsName); ?>

                    -
                    <?php echo e($additional_link->TrackTitle); ?>

                    MP3
                </a>
            </section>
        <?php endif; ?>

        <?php if($video->isNotEmpty()): ?>
            <section class="ts-video-detail-section ts-video-detail-related">
                <h2 class="ts-video-detail-section-heading">
                    More <?php echo e($artist->ArtistsName); ?> Videos
                </h2>

                <div class="ts-video-detail-related-list">
                    <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a
                            class="ts-video-detail-related-item"
                            href="<?php echo e(route('pages.videos_detail', [
                                $row->id,
                                \Illuminate\Support\Str::slug(
                                    trim(
                                        ($row->ArtistsName ?? '')
                                        . ' '
                                        . ($row->TrackTitle ?? '')
                                    )
                                ),
                            ])); ?>"
                        >
                            <div class="ts-video-detail-related-cover">
                                <?php echo $__env->make('pages.partials.cover', [
                                    'src' => $row->CoverUrl,
                                    'folder' => '',
                                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                                <span class="ts-video-detail-related-play">
                                    <i class="fa fa-play" aria-hidden="true"></i>
                                </span>
                            </div>

                            <div class="ts-video-detail-related-info">
                                <h3><?php echo e($row->ArtistsName); ?></h3>
                                <p><?php echo e($row->TrackTitle); ?></p>

                                <?php if($row->directedby): ?>
                                    <span>Directed by <?php echo e($row->directedby); ?></span>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if($audio->isNotEmpty()): ?>
            <section class="ts-related-section ts-video-detail-related">
                <h2 class="ts-video-detail-section-heading">
                    Download <?php echo e($artist->ArtistsName); ?> Other Songs
                </h2>

                <div class="ts-music-list">
                    <?php $__currentLoopData = $audio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="ts-music-list-item">
                        <a
                            class="ts-music-list-link"
                            href="<?php echo e(route('pages.musics_detail', [
                                $row->id,
                                \Illuminate\Support\Str::slug(
                                    trim(($row->ArtistsName ?? '') . ' ' . ($row->TrackTitle ?? ''))
                                ),
                            ])); ?>"
                        >
                                <div class="ts-music-list-cover">
                                    <?php echo $__env->make('pages.partials.cover', [
                                        'src' => $row->CoverUrl,
                                        'folder' => '',
                                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </div>

                                <div class="ts-music-list-info">
                                    <h3 class="ts-music-list-artist">
                                        <?php echo e($row->ArtistsName); ?>

                                    </h3>

                                    <p class="ts-music-list-title">
                                        <?php echo e($row->TrackTitle); ?>

                                    </p>

                                    <?php if($row->Featuring): ?>
                                        <span class="ts-music-list-featuring">
                                            feat. <?php echo e($row->Featuring); ?>

                                        </span>
                                    <?php endif; ?>

                                    <?php if($row->producedby): ?>
                                        <p class="ts-music-list-producer">
                                            Produced by <?php echo e($row->producedby); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </a>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if($music->isNotEmpty()): ?>
            <section class="ts-related-section ts-video-detail-related">
                <h2 class="ts-video-detail-section-heading">
                    Download Latest Music MP3 & Videos
                </h2>

                <div class="ts-music-list">
                    <?php $__currentLoopData = $music; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isVideo = $row->ListingType === 'video';

                            $itemUrl = $isVideo
                                ? route('pages.videos_detail', [
                                    $row->id,
                                    \Illuminate\Support\Str::slug(
                                        trim(
                                            ($row->ArtistsName ?? '')
                                            . ' '
                                            . ($row->TrackTitle ?? '')
                                        )
                                    ),
                                ])
                                : route('pages.musics_detail', [
                                    $row->id,
                                    \Illuminate\Support\Str::slug(
                                        trim(
                                            ($row->ArtistsName ?? '')
                                            . ' '
                                            . ($row->TrackTitle ?? '')
                                        )
                                    ),
                                ]);
                        ?>

                        <article class="ts-music-list-item">
                            <a class="ts-music-list-link" href="<?php echo e($itemUrl); ?>">
                                <div class="ts-music-list-cover">
                                    <?php echo $__env->make('pages.partials.cover', [
                                        'src' => $row->CoverUrl,
                                        'folder' => '',
                                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </div>

                                <div class="ts-music-list-info">
                                    <h3 class="ts-music-list-artist">
                                        <?php echo e($row->ArtistsName); ?>

                                    </h3>

                                    <p class="ts-music-list-title">
                                        <?php echo e($row->TrackTitle); ?>

                                    </p>

                                    <?php if($row->Featuring): ?>
                                        <span class="ts-music-list-featuring">
                                            feat. <?php echo e($row->Featuring); ?>

                                        </span>
                                    <?php endif; ?>

                                    <?php if($row->directedby): ?>
                                        <p class="ts-music-list-producer">
                                            Directed by <?php echo e($row->directedby); ?>

                                        </p>
                                    <?php elseif($row->producedby): ?>
                                        <p class="ts-music-list-producer">
                                            Produced by <?php echo e($row->producedby); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </a>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/videos_detail.blade.php ENDPATH**/ ?>