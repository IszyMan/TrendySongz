<?php
    $pageTitle = 'Music News - Top Naija Celebrity News, Entertainment gists & Updates';
    $pageDescription = 'Latest Celebrity and Hot Gist and Entertainment Updates';

    $canonicalUrl = $rows->currentPage() > 1
        ? $rows->url($rows->currentPage())
        : url('/music-news');
?>

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($pageDescription); ?>">
    <meta
        name="keywords"
        content="music news, Naija celebrity news, Nigerian entertainment news, latest music news, celebrity gist, entertainment updates"
    >
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="TrendySongz">
    <meta property="og:title" content="<?php echo e($pageTitle); ?>">
    <meta property="og:description" content="<?php echo e($pageDescription); ?>">
    <meta property="og:url" content="<?php echo e($canonicalUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="<?php echo e($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($pageDescription); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-music-news-page">
        <header class="ts-section-heading">
            <div>
                <h1 class="ts-visually-hidden">Music News</h1>               

                <p class="ts-music-news-subheading">
                    Latest celebrity news, entertainment gist and music updates.
                </p>
            </div>

            <div class="ts-music-news-date">
                <time datetime="<?php echo e(now()->toDateString()); ?>">
                    <?php echo e(now()->format('M j, Y')); ?>

                </time>
                
            </div>
        </header>

        

        <div class="ts-music-news-list">
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $postUrl = route('pages.celebritynews_details', [
                        $row->id,
                        \Illuminate\Support\Str::slug($row->title),
                    ]);

                    $intro = \Illuminate\Support\Str::limit(
                        trim(preg_replace(
                            '/\s+/u',
                            ' ',
                            strip_tags($row->intro ?: $row->description ?: '')
                        )),
                        400
                    );

                    $postDate = $row->created_at
                        ? \Illuminate\Support\Carbon::parse($row->created_at)
                        : null;
                ?>

                <article class="ts-music-news-card">
                    <a class="ts-music-news-card-link" href="<?php echo e($postUrl); ?>">
                        <?php if($row->photo): ?>
                            <span class="ts-music-news-image">
                                <img
                                    src="<?php echo e(asset('images/blog/' . ltrim($row->photo, '/'))); ?>"
                                    alt="<?php echo e($row->title); ?>"
                                    loading="lazy"
                                >
                            </span>
                        <?php endif; ?>

                        <span class="ts-music-news-content">
                            <span class="ts-music-news-title">
                                <?php echo e($row->title); ?>

                            </span>

                            <?php if($intro !== ''): ?>
                                <span class="ts-music-news-intro">
                                    <?php echo e($intro); ?>

                                </span>
                            <?php endif; ?>
                        </span>

                        <span class="ts-music-news-meta">
                            <span>
                                Posted by <?php echo e($row->posted_by_name ?: 'Wilfred Moses'); ?>

                            </span>

                            <?php if($postDate): ?>
                                <span class="ts-music-news-meta-separator">•</span>

                                <time
                                    class="ts-music-news-post-date"
                                    datetime="<?php echo e($postDate->toDateString()); ?>"
                                >
                                    <?php echo e($postDate->format('M j, Y')); ?>

                                </time>
                            <?php endif; ?>
                        </span>

                        <span class="ts-music-news-read-more">
                            Continue Reading
                            <i
                                class="fa fa-arrow-right ts-music-news-arrow"
                                aria-hidden="true"
                            ></i>
                        </span>
                    </a>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No music news has been published yet.</p>
            <?php endif; ?>
        </div>

        <?php if($rows->hasPages()): ?>
            <div class="ts-list-pagination">
                <?php echo e($rows->links('vendor.pagination.trendysongz')); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/celebrity_news.blade.php ENDPATH**/ ?>