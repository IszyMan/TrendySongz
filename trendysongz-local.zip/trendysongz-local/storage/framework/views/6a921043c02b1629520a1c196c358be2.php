

<?php $__env->startSection('title', 'Albums'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Albums</h1>

    <div class="admin-panel">
        <form
            class="admin-toolbar"
            method="GET"
            action="<?php echo e(route('admin.albums.index')); ?>"
        >
            <input
                type="search"
                name="q"
                value="<?php echo e($search); ?>"
                placeholder="Search albums"
                aria-label="Search albums"
            >

            <button
                class="admin-button"
                type="submit"
            >
                Search
            </button>

            <a
                class="admin-button"
                href="<?php echo e(route('admin.albums.create')); ?>"
            >
                Add album
            </a>
        </form>

        <div class="admin-table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Album</th>
                        <th>Artist</th>
                        <th>Released</th>
                        <th>Published</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($album->id); ?></td>
                            <td><?php echo e($album->title); ?></td>
                            <td>
                                <?php echo e($album->ArtistsName
                                    ?: $album->Stage_Name); ?>

                            </td>
                            <td>
                                <?php echo e($album->released_year); ?>

                            </td>
                            <td>
                                <?php echo e($album->IsPublished); ?>

                            </td>

                            <td>
                                <?php if(
                                    (int) auth()->user()->roleid === 1
                                    || (int) $album->user_id
                                        === (int) auth()->id()
                                ): ?>
                                    <div class="admin-actions">
                                        <a
                                            class="admin-button admin-button-secondary"
                                            href="<?php echo e(route(
                                                'admin.albums.edit',
                                                $album->id
                                            )); ?>"
                                        >
                                            Edit
                                        </a>

                                        <form
                                            method="POST"
                                            action="<?php echo e(route(
                                                'admin.albums.destroy',
                                                $album->id
                                            )); ?>"
                                            onsubmit="return confirm('Delete this album?')"
                                        >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button
                                                class="admin-danger"
                                                type="submit"
                                            >
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">
                                No albums found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="ts-list-pagination">
            <?php echo e($albums->links(
                'vendor.pagination.trendysongz'
            )); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/albums/index.blade.php ENDPATH**/ ?>