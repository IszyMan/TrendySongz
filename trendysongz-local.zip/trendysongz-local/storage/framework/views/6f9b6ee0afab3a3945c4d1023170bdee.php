<?php
    $editing = isset($album);
?>

<form
    class="admin-panel admin-grid"
    method="POST"
    action="<?php echo e($editing
        ? route('admin.albums.update', $album->id)
        : route('admin.albums.store')); ?>"
    enctype="multipart/form-data"
>
    <?php echo csrf_field(); ?>

    <?php if($editing): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <label>
        Artist

        <select name="artist_id" required>
            <option value="">Choose artist</option>

            <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($artist->Artists_Id); ?>"
                    <?php if(
                        old(
                            'artist_id',
                            $album->artist_id ?? ''
                        ) === $artist->Artists_Id
                    ): echo 'selected'; endif; ?>
                >
                    <?php echo e($artist->ArtistsName
                        ?: $artist->Stage_Name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <label class="admin-wide">
        Album title

        <input
            name="title"
            maxlength="5000"
            value="<?php echo e(old(
                'title',
                $album->title ?? ''
            )); ?>"
            required
        >
    </label>

    <label>
        Featuring

        <input
            name="featuring"
            maxlength="100"
            value="<?php echo e(old(
                'featuring',
                $album->featuring ?? ''
            )); ?>"
        >
    </label>

    <label>
        Release year

        <input
            name="released_year"
            maxlength="36"
            value="<?php echo e(old(
                'released_year',
                $album->released_year ?? ''
            )); ?>"
            required
        >
    </label>

    <label>
        Release date

        <input
            type="date"
            name="released_date"
            required
            value="<?php echo e(old(
                'released_date',
                isset($album) && $album->released_date
                    ? \Illuminate\Support\Carbon::parse(
                        $album->released_date
                    )->toDateString()
                    : now()->toDateString()
            )); ?>"
        >
    </label>

    <label>
        Album cover

        <input
            type="file"
            name="image"
            accept="image/jpeg,image/png,image/webp"
            <?php if(! $editing): echo 'required'; endif; ?>
        >

        <?php if($editing && $album->cover_url): ?>
            <span class="admin-file-note">
                Current: <?php echo e($album->cover_url); ?>.
                Leave empty to keep it.
            </span>
        <?php endif; ?>
    </label>

    <label class="admin-wide">
        Description

        <textarea name="description"><?php echo e(old(
            'description',
            $album->description ?? ''
        )); ?></textarea>
    </label>

    <input type="hidden" name="show_ads" value="0">

    <input type="hidden" name="publish" value="0">

    <label class="admin-check">
        <input
            type="checkbox"
            name="publish"
            value="1"
            <?php if(
                old(
                    'publish',
                    $editing
                        && $album->IsPublished === 'YES'
                )
            ): echo 'checked'; endif; ?>
        >
        Published
    </label>

    

    <div class="admin-wide">
        <button
            class="admin-button"
            type="submit"
        >
            <?php echo e($editing
                ? 'Save changes'
                : 'Save album'); ?>

        </button>
    </div>
</form><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/albums/form.blade.php ENDPATH**/ ?>