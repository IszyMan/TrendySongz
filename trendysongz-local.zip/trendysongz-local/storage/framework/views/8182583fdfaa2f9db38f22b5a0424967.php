<?php
    $editing = isset($artist);
?>

<form
    class="admin-panel admin-grid"
    method="POST"
    action="<?php echo e($editing
        ? route('admin.artists.update', $artist->id)
        : route('admin.artists.store')); ?>"
    enctype="multipart/form-data"
>
    <?php echo csrf_field(); ?>

    <?php if($editing): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <label>
        Artist name
        <input
            name="ArtistsName"
            maxlength="100"
            value="<?php echo e(old('ArtistsName', $artist->ArtistsName ?? '')); ?>"
            required
        >
    </label>

    <label>
        Stage name (unique)
        <input
            name="Stage_Name"
            maxlength="100"
            value="<?php echo e(old('Stage_Name', $artist->Stage_Name ?? '')); ?>"
            required
        >
    </label>

    <label>
        Country
        <select name="country_id" required>
            <?php $__currentLoopData = [
                'naija' => 'Nigeria',
                'ghana' => 'Ghana',
                'african' => 'Other African country',
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($value); ?>"
                    <?php if(old('country_id', $artist->country_id ?? 'naija') === $value): echo 'selected'; endif; ?>
                >
                    <?php echo e($label); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <label>
        Full name
        <input
            name="Fullname"
            maxlength="100"
            value="<?php echo e(old('Fullname', $artist->Fullname ?? '')); ?>"
        >
    </label>

    <label>
        Record label
        <input
            name="RecordLabel"
            maxlength="100"
            value="<?php echo e(old('RecordLabel', $artist->RecordLabel ?? '')); ?>"
        >
    </label>

    <label>
        Genre
        <input
            name="Genres"
            maxlength="100"
            value="<?php echo e(old('Genres', $artist->Genres ?? '')); ?>"
        >
    </label>

    <label>
        Artist image
        <input
            type="file"
            name="image"
            accept="image/jpeg,image/png,image/webp"
        >

        <?php if($editing && $artist->ProfilePic): ?>
            <span class="admin-file-note">
                Current: <?php echo e($artist->ProfilePic); ?>. Leave empty to keep it.
            </span>
        <?php endif; ?>
    </label>

    <label class="admin-wide">
        Short profile
        <textarea
            name="ArtistsProfile"
            maxlength="100"
        ><?php echo e(old('ArtistsProfile', $artist->ArtistsProfile ?? '')); ?></textarea>
    </label>

    <input type="hidden" name="publish" value="0">

    <label class="admin-check">
        <input
            type="checkbox"
            name="publish"
            value="1"
            <?php if(old('publish', isset($artist) && $artist->IsPublished === 'YES')): echo 'checked'; endif; ?>
        >
        Published
    </label>

    <div class="admin-wide">
        <button class="admin-button" type="submit">
            <?php echo e($editing ? 'Save changes' : 'Save artiste'); ?>

        </button>
    </div>
</form><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/artists/form.blade.php ENDPATH**/ ?>