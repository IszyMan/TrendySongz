

<?php $__env->startSection('title', 'Edit artiste'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edit <?php echo e($artist->ArtistsName ?: $artist->Stage_Name); ?></h1>

    <p>Leave the image field empty to keep the current image.</p>

    <?php echo $__env->make('admin.artists.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/artists/edit.blade.php ENDPATH**/ ?>