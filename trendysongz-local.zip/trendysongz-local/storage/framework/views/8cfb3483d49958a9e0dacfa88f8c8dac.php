<?php
    $editing = isset($mix);
?>

<form
    class="admin-panel admin-grid"
    method="POST"
    action="<?php echo e($editing
        ? route('admin.dj-mixes.update', $mix->id)
        : route('admin.dj-mixes.store')); ?>"
    enctype="multipart/form-data"
>
    <?php echo csrf_field(); ?>

    <?php if($editing): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <label>
        DJ name

        <select name="dj_id" required>
            <option value="">Choose DJ</option>

            <?php $__currentLoopData = $djs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($dj->id); ?>"
                    <?php if(
                        (string) old(
                            'dj_id',
                            $mix->dj_id ?? ''
                        ) === (string) $dj->id
                    ): echo 'selected'; endif; ?>
                >
                    <?php echo e($dj->dj_name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <label>
        Mixtape title

        <input
            name="mix_title"
            maxlength="50"
            value="<?php echo e(old('mix_title', $mix->mix_title ?? '')); ?>"
            required
        >
    </label>

    <label>
        Release year

        <input
            name="released_year"
            maxlength="36"
            value="<?php echo e(old(
                'released_year',
                $mix->released_year ?? ''
            )); ?>"
        >
    </label>

    <label>
        Cover image

        <input
            type="file"
            name="image"
            accept="image/jpeg,image/png,image/webp"
        >

        <?php if($editing && $mix->cover_url): ?>
            <span class="admin-file-note">
                Current: <?php echo e($mix->cover_url); ?>.
                Leave empty to keep it.
            </span>
        <?php endif; ?>
    </label>

    <label>
        Back cover (optional)

        <input
            type="file"
            name="back_image"
            accept="image/jpeg,image/png,image/webp"
        >

        <?php if($editing && $mix->back_cover): ?>
            <span class="admin-file-note">
                Current: <?php echo e($mix->back_cover); ?>.
                Leave empty to keep it.
            </span>
        <?php endif; ?>
    </label>

    <label class="admin-wide">
        DJ mix audio (200 MB maximum)

        <input
            type="file"
            name="media"
            accept=".mp3,.m4a,.wav,.aac"
            <?php if(! $editing): echo 'required'; endif; ?>
        >

        <?php if($editing && $mix->track_url): ?>
            <span class="admin-file-note">
                Current: <?php echo e($mix->track_url); ?>.
                Leave empty to keep it.
            </span>
        <?php endif; ?>
    </label>

    <label class="admin-wide">
        Details

        <textarea
            name="details"
            maxlength="1000"
        ><?php echo e(old('details', $mix->details ?? '')); ?></textarea>
    </label>

    <label class="admin-wide">
        More details

        <textarea
            name="details2"
            maxlength="1000"
        ><?php echo e(old('details2', $mix->details2 ?? '')); ?></textarea>
    </label>

    <label class="admin-wide">
        Description

        <textarea
            name="description1"
        ><?php echo e(old(
            'description1',
            $mix->description1 ?? ''
        )); ?></textarea>
    </label>

    <label class="admin-wide">
        More description

        <textarea
            name="description2"
        ><?php echo e(old(
            'description2',
            $mix->description2 ?? ''
        )); ?></textarea>
    </label>

    <input type="hidden" name="publish" value="0">

    <label class="admin-check">
        <input
            type="checkbox"
            name="publish"
            value="1"
            <?php if(
                old(
                    'publish',
                    $editing
                        && $mix->IsPublished === 'YES'
                )
            ): echo 'checked'; endif; ?>
        >
        Published
    </label>

    <div class="admin-wide">
        <button
            class="admin-button"
            type="submit"
        >
            <?php echo e($editing
                ? 'Save changes'
                : 'Save DJ mix'); ?>

        </button>
    </div>
</form><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/dj-mixes/form.blade.php ENDPATH**/ ?>