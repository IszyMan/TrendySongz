<?php $__env->startSection('title', 'Add user'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Add user</h1>
    <form class="admin-panel admin-grid" method="POST" action="<?php echo e(route('admin.users.store')); ?>">
        <?php echo csrf_field(); ?>
        <label>Name <input name="name" maxlength="50" value="<?php echo e(old('name')); ?>" required></label>
        <label>Email <input type="email" name="email" value="<?php echo e(old('email')); ?>" required></label>
        <label>Role <select name="roleid" required>
            <option value="3" <?php if(old('roleid') === '3'): echo 'selected'; endif; ?>>Standard User — uploads</option>
            <option value="2" <?php if(old('roleid') === '2'): echo 'selected'; endif; ?>>Editor — blogs</option>
        </select></label>
        <label>Password <input type="password" name="password" minlength="12" autocomplete="new-password" required></label>
        <label>Confirm password <input type="password" name="password_confirmation" minlength="12" autocomplete="new-password" required></label>
        <div class="admin-wide"><button class="admin-button" type="submit">Create user</button></div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/users/create.blade.php ENDPATH**/ ?>