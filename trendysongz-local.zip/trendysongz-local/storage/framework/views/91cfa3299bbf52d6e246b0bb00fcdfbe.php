

<?php
    $artistName = $album->ArtistsName ?: 'Unknown Artist';
    $albumName = $artistName . ' - ' . $album->title;

    $pageTitle = $albumName . ' | Download Album - Trendysongz';

    $descriptionText = trim(
        preg_replace(
            '/\s+/u',
            ' ',
            strip_tags($album->description ?: '')
        )
    );

    $metaDescription = trim(
        'Download ' . $albumName . ' ' . $descriptionText
    );

    $canonicalUrl = route('pages.album_details', [
        $album->id,
        \Illuminate\Support\Str::slug($albumName),
    ]);

    $coverUrl = $album->cover_url
        ? asset('images/' . ltrim($album->cover_url, '/'))
        : null;
?>

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($metaDescription); ?>">
    <meta name="keywords" content="<?php echo e($albumName); ?>, download <?php echo e($albumName); ?>, download <?php echo e($albumName); ?> mp3, <?php echo e($albumName); ?> album, download album, download latest Nigerian album">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="music.album">
    <meta property="og:site_name" content="TrendySongz">
    <meta property="og:title" content="<?php echo e($pageTitle); ?>">
    <meta property="og:description" content="<?php echo e($metaDescription); ?>">
    <meta property="og:url" content="<?php echo e($canonicalUrl); ?>">

    <?php if($coverUrl): ?>
        <meta property="og:image" content="<?php echo e($coverUrl); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="<?php echo e($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($metaDescription); ?>">

    <?php if($coverUrl): ?>
        <meta name="twitter:image" content="<?php echo e($coverUrl); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-album-detail">
        <header class="ts-album-detail-header">
            <h1 class="ts-album-detail-title">
                <?php echo e($albumName); ?> | Download Album
            </h1>

            <div class="ts-album-detail-post-meta">
                <span class="ts-album-detail-posted-by">
                    <a
                        class="ts-album-detail-posted-by"
                        href="<?php echo e(route(
                            'pages.albums_posted_by',
                            \Illuminate\Support\Str::slug($album->posted_by_name ?: 'Wilfred Moses')
                        )); ?>"
                    >
                        Posted by:
                        <?php echo e($album->posted_by_name ?: 'TrendySongz'); ?>

                        <i class="fa fa-check-circle" aria-hidden="true"></i>
                    </a>
                    
                </span>

                <?php if($album->created_at): ?>
                    <span class="ts-album-detail-meta-separator">•</span>

                    <time
                        class="ts-album-detail-date"
                        datetime="<?php echo e(\Illuminate\Support\Carbon::parse($album->created_at)->toDateString()); ?>"
                    >
                        <?php echo e(\Illuminate\Support\Carbon::parse($album->created_at)->format('M d, Y')); ?>

                    </time>
                <?php endif; ?>
            </div>
        </header>

        <div class="ts-album-detail-info-bar">
            <div class="ts-album-detail-info-item">
                <span class="ts-album-detail-info-label">Released</span>

                <?php if($album->released_year): ?>
                    <a
                        class="ts-album-detail-info-value "
                        href="<?php echo e(route('pages.albums_released_year', [
                            'year' => $album->released_year,
                        ])); ?>"
                    >
                        <?php echo e($album->released_year); ?>

                    </a>
                <?php else: ?>
                    <span class="ts-album-detail-info-value">—</span>
                <?php endif; ?>
            </div>

            <div class="ts-album-detail-info-item">
                <span class="ts-album-detail-info-label">
                    Tracks
                </span>

                <span class="ts-album-detail-info-value">
                    <?php echo e($tracks->count()); ?>

                </span>
            </div>

            <div class="ts-album-detail-info-item">
                <span class="ts-album-detail-info-label">
                    Category
                </span>

                <span class="ts-album-detail-info-value">
                    <a href="<?php echo e(route('pages.album')); ?>">
                        Album / EP
                    </a>
                </span>
            </div>
        </div>

        <section class="ts-album-detail-hero">
            <div class="ts-album-detail-cover">
                <?php echo $__env->make('pages.partials.cover', [
                    'src' => $album->cover_url,
                    'folder' => '',
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <div class="ts-album-detail-content">
                <h2 class="ts-album-detail-artist">
                    <?php echo e($artistName); ?>

                </h2>

                <div class="ts-album-detail-album-title">
                    <?php echo e($album->title); ?>

                </div>

                <?php if($album->featuring): ?>
                    <div class="ts-album-detail-meta-row">
                        <span class="ts-album-detail-meta-label">
                            Featuring:
                        </span>

                        <span class="ts-album-detail-meta-value">
                            <?php echo e($album->featuring); ?>

                        </span>
                    </div>
                <?php endif; ?>

                <?php if($album->released_date): ?>
                    <div class="ts-album-detail-meta-row">
                        <span class="ts-album-detail-meta-label">
                            Release date:
                        </span>

                        <time
                            class="ts-album-detail-meta-value"
                            datetime="<?php echo e(\Illuminate\Support\Carbon::parse($album->released_date)->toDateString()); ?>"
                        >
                            <?php echo e(\Illuminate\Support\Carbon::parse($album->released_date)->format('M d, Y')); ?>

                        </time>
                    </div>
                <?php endif; ?>

                <div class="ts-album-detail-meta-row">
                    <span class="ts-album-detail-meta-label">
                        Tracklist:
                    </span>

                    <span class="ts-album-detail-meta-value">
                        <?php echo e($tracks->count()); ?>

                        <?php echo e($tracks->count() === 1 ? 'song' : 'songs'); ?>

                    </span>
                </div>
            </div>
        </section>

        <?php if($descriptionText !== ''): ?>
            <section class="ts-album-detail-section ts-album-detail-about">
                <h2 class="ts-album-detail-section-heading">
                    About this album
                </h2>

                <div class="ts-album-detail-about-text">
                    <?php echo nl2br(e($descriptionText)); ?>

                </div>
            </section>
        <?php endif; ?>

        <section class="ts-album-detail-tracklist-section">
            <h2 class="ts-album-detail-section-heading">
                <?php echo e($album->title); ?> Tracklist
            </h2>

            <div class="ts-album-detail-tracklist">
                <?php $__empty_1 = true; $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="ts-album-detail-track">
                        <a
                            class="ts-album-detail-track-link"
                            href="<?php echo e(route('pages.musics_detail', [
                                $track->id,
                                \Illuminate\Support\Str::slug(
                                    trim(
                                        ($track->ArtistsName ?? '')
                                        . ' '
                                        . ($track->TrackTitle ?? '')
                                    )
                                ),
                            ])); ?>"
                        >
                            <span class="ts-album-detail-track-number">
                                <?php echo e($track->track_number ?: $loop->iteration); ?>

                            </span>

                            <span class="ts-album-detail-track-info">
                                <span class="ts-album-detail-track-title">
                                    <?php echo e($track->TrackTitle); ?>

                                </span>

                                <span class="ts-album-detail-track-artists">
                                    <span class="ts-album-detail-track-artist">
                                        <?php echo e($track->ArtistsName ?: $artistName); ?>

                                    </span>

                                    <?php if($track->Featuring): ?>
                                        <span class="ts-album-detail-track-featuring">
                                            feat. <?php echo e($track->Featuring); ?>

                                        </span>
                                    <?php endif; ?>
                                </span>

                                <?php if($track->producedby): ?>
                                    <span class="ts-album-detail-track-producer">
                                        Produced by <?php echo e($track->producedby); ?>

                                    </span>
                                <?php endif; ?>
                            </span>
                        </a>

                        <span class="ts-album-detail-track-actions" aria-hidden="true">
                            <span class="ts-album-detail-track-action">
                                <i class="fa fa-download"></i>
                            </span>
                        </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="ts-album-detail-empty">
                        No tracks have been added to this album yet.
                    </p>
                <?php endif; ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/album_details.blade.php ENDPATH**/ ?>