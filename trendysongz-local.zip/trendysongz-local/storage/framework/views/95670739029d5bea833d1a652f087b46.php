

<?php $__env->startSection('title', 'Add DJ'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Add DJ</h1>

    <?php echo $__env->make('admin.djs.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/djs/create.blade.php ENDPATH**/ ?>