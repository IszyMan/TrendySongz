

<?php
    $articleTitle = trim($blog->title);

    $pageTitle = $articleTitle . ' - TrendySongz';

    $metaDescription = \Illuminate\Support\Str::limit(
        trim(preg_replace(
            '/\s+/u',
            ' ',
            strip_tags($blog->intro ?: $articleTitle)
        )),
        160
    );

    $canonicalUrl = route('pages.celebritynews_details', [
        $blog->id,
        \Illuminate\Support\Str::slug($articleTitle),
    ]);

    $imageUrl = $blog->photo
        ? asset('images/blog/' . ltrim($blog->photo, '/'))
        : null;

    $postedDate = $blog->created_at
        ? \Illuminate\Support\Carbon::parse($blog->created_at)
        : null;
?>

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($metaDescription); ?>">
    <meta
        name="keywords"
        content="<?php echo e($articleTitle); ?>, music news, Nigerian music news, celebrity news, entertainment news"
    >
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="article">
    <meta property="og:site_name" content="TrendySongz">
    <meta property="og:title" content="<?php echo e($articleTitle); ?>">
    <meta property="og:description" content="<?php echo e($metaDescription); ?>">
    <meta property="og:url" content="<?php echo e($canonicalUrl); ?>">

    <?php if($imageUrl): ?>
        <meta property="og:image" content="<?php echo e($imageUrl); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@TrendySongz_">
    <meta name="twitter:title" content="<?php echo e($articleTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($metaDescription); ?>">

    <?php if($imageUrl): ?>
        <meta name="twitter:image" content="<?php echo e($imageUrl); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-blog-page">
        <article class="ts-blog-detail">
            <header class="ts-blog-header">
                <h1 class="ts-blog-title"><?php echo e($articleTitle); ?></h1>

                <div class="ts-blog-meta">
                    <span>
                        Posted by:
                        <?php echo e($blog->posted_by_name ?: 'TrendySongz'); ?>

                    </span>

                    <?php if($postedDate): ?>
                        <span aria-hidden="true">•</span>

                        <time datetime="<?php echo e($postedDate->toDateString()); ?>">
                            <?php echo e($postedDate->format('M j, Y')); ?>

                        </time>
                    <?php endif; ?>
                </div>
            </header>

            <?php if($imageUrl): ?>
                <figure class="ts-blog-featured-image">
                    <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($articleTitle); ?>">
                </figure>
            <?php endif; ?>

            <?php if(filled($blog->intro)): ?>
                <div class="ts-blog-intro">
                    <?php echo nl2br(e(strip_tags($blog->intro))); ?>

                </div>
            <?php endif; ?>

            <div class="ts-blog-body">
                <?php $__currentLoopData = [
                    'description',
                    'desc2',
                    'desc3',
                    'desc4',
                    'desc5',
                    'desc6',
                    'desc7',
                    'desc8',
                    'desc9',
                    'desc10',
                    'Desc11',
                    'Desc12',
                    'Desc13',
                    'Desc14',
                    'Desc15',
                    'Desc16',
                    'Desc17',
                    'Desc18',
                    'Desc19',
                    'Desc20',
                    'Desc21',
                    'Desc22',
                    'Desc23',
                    'Desc24',
                    'Desc25',
                    'Desc26',
                    'Desc27',
                    'Desc28',
                    'Desc29',
                    'Desc30',
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(filled($blog->{$field} ?? null)): ?>
                        <p><?php echo nl2br(e(strip_tags($blog->{$field}))); ?></p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <p class="ts-blog-source">Source: TrendySongz</p>
        </article>


        <?php if($related_blog->isNotEmpty()): ?>
            <section class="ts-blog-related">
                <h2>Related Music News</h2>

                <div class="ts-blog-related-list">
                    <?php $__currentLoopData = $related_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a
                            class="ts-blog-related-card"
                            href="<?php echo e(route('pages.celebritynews_details', [
                                $related->id,
                                \Illuminate\Support\Str::slug($related->title),
                            ])); ?>"
                        >
                            <?php if($related->photo): ?>
                                <img
                                    src="<?php echo e(asset('images/blog/' . ltrim($related->photo, '/'))); ?>"
                                    alt=""
                                    loading="lazy"
                                >
                            <?php endif; ?>

                            <span><?php echo e($related->title); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/celebritynews_details.blade.php ENDPATH**/ ?>