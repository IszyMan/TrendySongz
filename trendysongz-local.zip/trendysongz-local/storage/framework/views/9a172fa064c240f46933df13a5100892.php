

<?php $__env->startSection('title', 'Edit listing'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edit <?php echo e($row->TrackTitle); ?></h1>

    <p>Leave the image or media field empty to keep its current file.</p>

    <?php echo $__env->make('admin.listings.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/listings/edit.blade.php ENDPATH**/ ?>