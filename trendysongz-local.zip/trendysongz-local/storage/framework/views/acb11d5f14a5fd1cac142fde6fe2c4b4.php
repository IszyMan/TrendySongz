

<?php $__env->startSection('title', 'Edit album'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edit <?php echo e($album->title); ?></h1>

    <p>
        Leave the cover image field empty to keep the current image.
    </p>

    <?php echo $__env->make('admin.albums.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/albums/edit.blade.php ENDPATH**/ ?>