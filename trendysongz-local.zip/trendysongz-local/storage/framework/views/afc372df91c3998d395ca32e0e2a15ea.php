<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link
        rel="icon"
        href="<?php echo e(asset('images/Trendysongz-favicon.ico')); ?>"
        type="image/x-icon"
    >
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">

    <title><?php echo $__env->yieldContent('title', 'Admin'); ?> | TrendySongz</title>
</head>
<body>
    <div class="admin-shell">
        <aside class="admin-side">
            <a class="admin-brand" href="<?php echo e(route('admin.dashboard')); ?>">
                TRENDYSONGZ Admin
            </a>

            <nav class="admin-nav" aria-label="Admin menu">
                <a
                    href="<?php echo e(route('admin.dashboard')); ?>"
                    <?php if(request()->routeIs('admin.dashboard')): ?>
                        class="active"
                        aria-current="page"
                    <?php endif; ?>
                >
                    Dashboard
                </a>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-content')): ?>
                    <details <?php if(request()->routeIs('admin.listings.*')): ?> open <?php endif; ?>>
                        <summary>Listing</summary>

                        <a
                            href="<?php echo e(route('admin.listings.index')); ?>"
                            <?php if(request()->routeIs('admin.listings.index', 'admin.listings.edit')): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            All listings
                        </a>

                        <a
                            href="<?php echo e(route('admin.listings.create')); ?>"
                            <?php if(request()->routeIs('admin.listings.create')): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            Add listing
                        </a>
                    </details>

                    <details <?php if(request()->routeIs('admin.artists.*')): ?> open <?php endif; ?>>
                        <summary>Artistes</summary>

                        <a
                            href="<?php echo e(route('admin.artists.index')); ?>"
                            <?php if(request()->routeIs('admin.artists.index')): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            All artistes
                        </a>

                        <a
                            href="<?php echo e(route('admin.artists.create')); ?>"
                            <?php if(request()->routeIs('admin.artists.create')): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            Add artiste
                        </a>
                    </details>


                    <details
                        <?php if(request()->routeIs('admin.albums.*')): ?>
                            open
                        <?php endif; ?>
                    >
                        <summary>Albums</summary>

                        <a
                            href="<?php echo e(route('admin.albums.index')); ?>"
                            <?php if(
                                request()->routeIs(
                                    'admin.albums.index',
                                    'admin.albums.edit'
                                )
                            ): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            All albums
                        </a>

                        <a
                            href="<?php echo e(route('admin.albums.create')); ?>"
                            <?php if(request()->routeIs('admin.albums.create')): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            Add album
                        </a>
                    </details>


                    <details
                        <?php if(request()->routeIs('admin.djs.*')): ?>
                            open
                        <?php endif; ?>>
                        <summary>DJs</summary>

                        <a
                            href="<?php echo e(route('admin.djs.index')); ?>"
                            <?php if(
                                request()->routeIs(
                                    'admin.djs.index',
                                    'admin.djs.edit'
                                )
                            ): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            All DJs
                        </a>

                        <a
                            href="<?php echo e(route('admin.djs.create')); ?>"
                            <?php if(request()->routeIs('admin.djs.create')): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            Add DJ
                        </a>
                    </details>


                    <details
                        <?php if(request()->routeIs('admin.dj-mixes.*')): ?>
                            open
                        <?php endif; ?>
                    >
                        <summary>DJ Mixes</summary>

                        <a
                            href="<?php echo e(route('admin.dj-mixes.index')); ?>"
                            <?php if(
                                request()->routeIs(
                                    'admin.dj-mixes.index',
                                    'admin.dj-mixes.edit'
                                )
                            ): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            All DJ mixes
                        </a>

                        <a
                            href="<?php echo e(route('admin.dj-mixes.create')); ?>"
                            <?php if(request()->routeIs('admin.dj-mixes.create')): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            Add DJ mix
                        </a>
                    </details>
                   
                <?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-blogs')): ?>
                    <details
                        <?php if(request()->routeIs('admin.blogs.*')): ?>
                            open
                        <?php endif; ?>
                    >
                        <summary>Blog</summary>

                        <a
                            href="<?php echo e(route('admin.blogs.index')); ?>"
                            <?php if(
                                request()->routeIs(
                                    'admin.blogs.index',
                                    'admin.blogs.edit'
                                )
                            ): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            All blog posts
                        </a>

                        <a
                            href="<?php echo e(route('admin.blogs.create')); ?>"
                            <?php if(request()->routeIs('admin.blogs.create')): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            Add blog post
                        </a>
                    </details>
                <?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-users')): ?>
                    <details <?php if(request()->routeIs('admin.users.*')): ?> open <?php endif; ?>>
                        <summary>Users</summary>

                        <a
                            href="<?php echo e(route('admin.users.index')); ?>"
                            <?php if(request()->routeIs('admin.users.index')): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            All users
                        </a>

                        <a
                            href="<?php echo e(route('admin.users.create')); ?>"
                            <?php if(request()->routeIs('admin.users.create')): ?>
                                class="active"
                                aria-current="page"
                            <?php endif; ?>
                        >
                            Add user
                        </a>
                    </details>

                    <details>
                        <summary>Settings</summary>
                        <span class="admin-pending">
                            Settings are next in the build
                        </span>
                    </details>
                <?php endif; ?>
            </nav>
        </aside>

        <main class="admin-content">
            <header class="admin-top">
                <p>Signed in as <?php echo e(auth()->user()->name); ?></p>

                <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                    <?php echo csrf_field(); ?>

                    <button class="admin-logout" type="submit">
                        Log out
                    </button>
                </form>
            </header>

            <?php if(session('status')): ?>
                <div class="admin-alert" role="status">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="admin-error" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/layout.blade.php ENDPATH**/ ?>