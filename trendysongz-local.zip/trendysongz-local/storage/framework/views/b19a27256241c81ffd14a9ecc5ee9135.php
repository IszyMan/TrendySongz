

<?php $__env->startSection('title', 'Video - Download Latest Videos - Music Videos and Comedy Videos'); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="Download Latest Videos - Music Videos and Comedy Videos and mp4, Naija Music Videos, Latest Comedy Videos, Latest Music Videos">
    <meta name="keywords" content="download latest video, latest video, latest naija music video, latest naija video, download latest naija video, Latest Comedy Videos, download comedy video,">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e(url('/download-latest-videos')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="TrendySongz">
    <meta property="og:title" content="Video - Download Latest Videos - Music Videos and Comedy Videos">
    <meta property="og:description" content="Download Latest Videos - Music Videos and Comedy Videos and mp4, Naija Music Videos, Latest Comedy Videos, Latest Music Videos">
    <meta property="og:url" content="<?php echo e(url('/download-latest-videos')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="Video - Download Latest Videos - Music Videos and Comedy Videos">
    <meta name="twitter:description" content="Download Latest Videos - Music Videos and Comedy Videos and mp4, Naija Music Videos, Latest Comedy Videos, Latest Music Videos">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-videos-page">
        <header class="ts-video-page-heading">
            <h1>Videos - Download Latest Naija Videos Here</h1>

            <time class="post-date" datetime="<?php echo e(now()->toDateString()); ?>">
                <?php echo e(now()->format('M d, Y')); ?>

            </time>
        </header>

        <div class="ts-video-list">
            <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a
                    class="ts-video-list-item"
                    href="<?php echo e(route('pages.videos_detail', [
                        $row->id,
                        \Illuminate\Support\Str::slug(
                            trim(($row->ArtistsName ?? '') . ' ' . ($row->TrackTitle ?? ''))
                        ),
                    ])); ?>"
                >
                    <div class="ts-video-list-cover">
                        <?php echo $__env->make('pages.partials.cover', [
                            'src' => $row->CoverUrl,
                            'folder' => '',
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <span class="ts-video-list-play" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="currentColor">
                                <path d="M8 5v14l11-7z"></path>
                            </svg>
                        </span>
                    </div>

                    <div class="ts-video-list-info">
                        <?php if($row->ArtistsName): ?>
                            <span class="ts-video-list-artist">
                                <?php echo e($row->ArtistsName); ?>

                            </span>
                        <?php endif; ?>

                        <span class="ts-video-list-title">
                            <?php echo e($row->TrackTitle); ?>

                        </span>

                        <?php if($row->Featuring): ?>
                            <span class="ts-video-list-featuring">
                                <span>Featuring:</span> <?php echo e($row->Featuring); ?>

                            </span>
                        <?php endif; ?>

                        <?php if($row->directedby): ?>
                            <span class="ts-video-list-directed">
                                <span>Directed by:</span> <?php echo e($row->directedby); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="ts-videos-empty">No videos found.</p>
            <?php endif; ?>
        </div>

        <div class="ts-list-pagination">
            <?php echo e($videos->links('vendor.pagination.trendysongz')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/videos.blade.php ENDPATH**/ ?>