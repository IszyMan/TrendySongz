<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Users</h1>
    <div class="admin-panel">
        <p><a class="admin-button" href="<?php echo e(route('admin.users.create')); ?>">Add user</a></p>
        <div class="admin-table-wrap"><table>
            <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr><td><?php echo e($user->id); ?></td><td><?php echo e($user->name); ?></td><td><?php echo e($user->email); ?></td><td><?php echo e($user->role_name); ?></td><td>
                    <?php if((int) $user->id !== (int) auth()->id() && (int) $user->roleid !== 1): ?>
                        <form method="POST" action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" onsubmit="return confirm('Delete this user account?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="admin-danger" type="submit">Delete</button>
                        </form>
                    <?php endif; ?>
                </td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table></div>
        <div class="admin-pagination"><?php echo e($users->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/users/index.blade.php ENDPATH**/ ?>