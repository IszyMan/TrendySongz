

<?php $__env->startSection('title', 'DJ mixes'); ?>

<?php $__env->startSection('content'); ?>
    <h1>DJ mixes</h1>

    <div class="admin-panel">
        <form
            class="admin-toolbar"
            method="GET"
            action="<?php echo e(route('admin.dj-mixes.index')); ?>"
        >
            <input
                type="search"
                name="q"
                value="<?php echo e($search); ?>"
                placeholder="Search DJ mixes"
                aria-label="Search DJ mixes"
            >

            <button
                class="admin-button"
                type="submit"
            >
                Search
            </button>

            <a
                class="admin-button"
                href="<?php echo e(route('admin.dj-mixes.create')); ?>"
            >
                Add DJ mix
            </a>
        </form>

        <div class="admin-table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Mixtape</th>
                        <th>DJ</th>
                        <th>Audio file</th>
                        <th>Published</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $mixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($mix->id); ?></td>
                            <td><?php echo e($mix->mix_title); ?></td>
                            <td><?php echo e($mix->dj_name); ?></td>
                            <td>
                                <?php echo e($mix->track_url ?: '—'); ?>

                            </td>
                            <td><?php echo e($mix->IsPublished); ?></td>

                            <td>
                                <?php if(
                                    (int) auth()->user()->roleid === 1
                                    || (int) $mix->user_id
                                        === (int) auth()->id()
                                ): ?>
                                    <div class="admin-actions">
                                        <a
                                            class="admin-button admin-button-secondary"
                                            href="<?php echo e(route(
                                                'admin.dj-mixes.edit',
                                                $mix->id
                                            )); ?>"
                                        >
                                            Edit
                                        </a>

                                        <form
                                            method="POST"
                                            action="<?php echo e(route(
                                                'admin.dj-mixes.destroy',
                                                $mix->id
                                            )); ?>"
                                            onsubmit="return confirm('Delete this DJ mix?')"
                                        >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button
                                                class="admin-danger"
                                                type="submit"
                                            >
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">
                                No DJ mixes found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="ts-list-pagination">
            <?php echo e($mixes->links(
                'vendor.pagination.trendysongz'
            )); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/dj-mixes/index.blade.php ENDPATH**/ ?>