

<?php
    $pageTitle = 'Albums - Download Latest Music Albums - Naija Music Albums Mp3 » TrendySongz';

    $description = 'Browse the latest music albums posted by ' . $poster->name . ' on TrendySongz. Explore Nigerian and African albums, discover new releases, and find songs to download.';

    $keywords = 'download latest albums, download album mp3, download latest music albums, download music mp3, latests songs, 2Baba, tekno, tiwa savage, burna boy, zlatan, mi, ycee, flavour,phyno, rema, olamide, d prince, akon, timaya, spinall, neptune, cuppy, kizz daniel, spinall, neptune, kizz daniel naija musics, nigerian songs, dj cuppy, new music, ycee, tekno, download music mp3, akon, ';

    $pageUrl = $albums->currentPage() === 1
        ? route('pages.albums_posted_by', [
            'slug' => \Illuminate\Support\Str::slug($poster->name),
        ])
        : $albums->url($albums->currentPage());
?>

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($description); ?>">
    <meta name="keywords" content="<?php echo e($keywords); ?>">
    <meta name="author" content="<?php echo e($poster->name); ?>">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e($pageUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="TrendySongz">
    <meta property="og:title" content="<?php echo e($pageTitle); ?>">
    <meta property="og:description" content="<?php echo e($description); ?>">
    <meta property="og:url" content="<?php echo e($pageUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="<?php echo e($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($description); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-artists-albums">
        <header class="ts-section-heading">
            <h1>Albums Posted by <?php echo e($poster->name); ?></h1>

            <p class="ts-albums-subheading">
                Download music albums and EPs posted by <?php echo e($poster->name); ?>

            </p>
        </header>

        <div class="ts-albums-date">
            <time datetime="<?php echo e(now()->toDateString()); ?>">
                <?php echo e(now()->format('M d, Y')); ?>

            </time>
        </div>

        <div class="ts-artists-albums-list">
            <?php $__empty_1 = true; $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $albumSlug = \Illuminate\Support\Str::slug(
                        trim(($row->ArtistsName ?? '') . ' ' . $row->title)
                    );
                ?>

                <a
                    class="ts-artist-album-card"
                    href="<?php echo e(route('pages.album_details', [
                        $row->id,
                        $albumSlug,
                    ])); ?>"
                >
                    <div class="ts-artist-album-cover">
                        <?php echo $__env->make('pages.partials.cover', [
                            'src' => $row->cover_url,
                            'folder' => '',
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>

                    <div class="ts-artist-album-details">
                        <?php if($row->ArtistsName): ?>
                            <span class="ts-artist-album-artist">
                                <?php echo e($row->ArtistsName); ?>

                            </span>
                        <?php endif; ?>

                        <h2 class="ts-artist-album-title">
                            <?php echo e($row->title); ?>

                        </h2>

                        <?php if($row->featuring): ?>
                            <p class="ts-artist-album-featuring">
                                Featuring <?php echo e($row->featuring); ?>

                            </p>
                        <?php endif; ?>

                        <div class="ts-artist-album-meta">
                            <?php if($row->released_year): ?>
                                <span class="ts-artist-album-meta-row">
                                    Released: <?php echo e($row->released_year); ?>

                                </span>
                            <?php endif; ?>

                            <span class="ts-artist-album-meta-row">
                                <?php echo e($row->track_count); ?>

                                <?php echo e($row->track_count == 1 ? 'Track' : 'Tracks'); ?>

                            </span>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="ts-artists-albums-empty">
                    No published albums or EPs found for <?php echo e($poster->name); ?>.
                </p>
            <?php endif; ?>
        </div>

        <?php if($albums->hasPages()): ?>
            <div>
                <?php echo e($albums->onEachSide(1)->links('vendor.pagination.trendysongz')); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/albums_posted_by.blade.php ENDPATH**/ ?>