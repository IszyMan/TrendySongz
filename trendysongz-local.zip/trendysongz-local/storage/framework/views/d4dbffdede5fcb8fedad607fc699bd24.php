<?php
    $editing = isset($dj);
?>

<form
    class="admin-panel admin-grid"
    method="POST"
    action="<?php echo e($editing
        ? route('admin.djs.update', $dj->id)
        : route('admin.djs.store')); ?>"
    enctype="multipart/form-data"
>
    <?php echo csrf_field(); ?>

    <?php if($editing): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <label>
        DJ name
        <input
            name="dj_name"
            maxlength="50"
            value="<?php echo e(old('dj_name', $dj->dj_name ?? '')); ?>"
            required
        >
    </label>

    <label>
        Full name
        <input
            name="fullname"
            maxlength="50"
            value="<?php echo e(old('fullname', $dj->fullname ?? '')); ?>"
        >
    </label>

    <label>
        Country
        <select name="country_id" required>
            <?php $__currentLoopData = [
                'naija' => 'Nigeria',
                'ghana' => 'Ghana',
                'african' => 'Other African country',
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($value); ?>"
                    <?php if(
                        old(
                            'country_id',
                            $dj->country_id ?? 'naija'
                        ) === $value
                    ): echo 'selected'; endif; ?>
                >
                    <?php echo e($label); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <label>
        Display order
        <input
            type="number"
            name="order_id"
            min="0"
            value="<?php echo e(old('order_id', $dj->order_id ?? 10000)); ?>"
        >
    </label>

    <label>
        DJ photo
        <input
            type="file"
            name="image"
            accept="image/jpeg,image/png,image/webp"
        >

        <?php if($editing && $dj->photo): ?>
            <span class="admin-file-note">
                Current: <?php echo e($dj->photo); ?>.
                Leave empty to keep it.
            </span>
        <?php endif; ?>
    </label>

    <label class="admin-wide">
        Profile / biography
        <textarea
            name="place_of_birth"
            maxlength="10000"
        ><?php echo e(old('place_of_birth', $dj->place_of_birth ?? '')); ?></textarea>
    </label>

    <label class="admin-wide">
        Awards
        <textarea name="award"><?php echo e(old('award', $dj->award ?? '')); ?></textarea>
    </label>

    <label class="admin-wide">
        Endorsements
        <textarea name="endorsement"><?php echo e(old('endorsement', $dj->endorsement ?? '')); ?></textarea>
    </label>

    <input type="hidden" name="publish" value="0">

    <label class="admin-check">
        <input
            type="checkbox"
            name="publish"
            value="1"
            <?php if(
                old(
                    'publish',
                    $editing && $dj->IsPublished === 'YES'
                )
            ): echo 'checked'; endif; ?>
        >
        Published
    </label>

    <div class="admin-wide">
        <button class="admin-button" type="submit">
            <?php echo e($editing ? 'Save changes' : 'Save DJ'); ?>

        </button>
    </div>
</form><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/djs/form.blade.php ENDPATH**/ ?>