<?php
    $artistName = $artist->ArtistsName ?: 'Unknown Artist';
    $pageTitle = $title . ' Mp3 Download » Trendysongz';

    $songDescription = trim(strip_tags(
        $artist->TrackInfo
        ?: $artist->introduction
        ?: $artist->trackinfo1
        ?: ''
    ));

    $metaDescription = \Illuminate\Support\Str::limit(
        "Download {$title} Mp3 Audio Music. {$songDescription}",
        200
    );

    $socialDescription = \Illuminate\Support\Str::limit(
        $songDescription ?: "Download {$title} Mp3 Audio Music on TrendySongz.",
        200
    );

    $keywords = implode(', ', [
        "{$artistName} {$artist->TrackTitle}",
        "Download {$title}",
        "Download {$artistName} {$artist->TrackTitle} mp3",
        "Download {$title} song",
        "download music mp3 {$artistName} {$artist->TrackTitle}",
        "{$artistName} {$artist->TrackTitle} free mp3",
    ]);

    $canonicalUrl = route('pages.musics_detail', [
        $artist->id,
        \Illuminate\Support\Str::slug($title),
    ]);

    $coverPath = 'images/' . ltrim((string) $artist->CoverUrl, '/');

    $coverUrl = $artist->CoverUrl && is_file(public_path($coverPath))
        ? asset($coverPath)
        : null;
?>

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($metaDescription); ?>">
    <meta name="keywords" content="<?php echo e($keywords); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="article">
    <meta property="og:title" content="<?php echo e($title); ?>">
    <meta property="og:description" content="<?php echo e($socialDescription); ?>">
    <meta property="og:url" content="<?php echo e($canonicalUrl); ?>">
    <meta property="og:site_name" content="TrendySongz">

    <?php if($coverUrl): ?>
        <meta property="og:image" content="<?php echo e($coverUrl); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="@Trendysongz">
    <meta name="twitter:title" content="<?php echo e($title); ?>">
    <meta name="twitter:description" content="<?php echo e($socialDescription); ?>">

    <?php if($coverUrl): ?>
        <meta name="twitter:image" content="<?php echo e($coverUrl); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
        $trackUrl = trim((string) ($artist->TrackUrl ?? ''));
        $mediaUrl = null;

        if (
            $trackUrl !== ''
            && basename($trackUrl) === $trackUrl
            && ! str_contains($trackUrl, '\\')
        ) {
            $path = 'media/audio/'.$trackUrl;

            if (\Illuminate\Support\Facades\Storage::disk('public')->exists($path)) {
                $mediaUrl = asset('storage/'.$path);
            }
        } elseif (str_starts_with($trackUrl, 'storage/media/audio/')) {
            // Supports listings uploaded before this filename-only change.
            $path = substr($trackUrl, strlen('storage/'));

            if (\Illuminate\Support\Facades\Storage::disk('public')->exists($path)) {
                $mediaUrl = asset($trackUrl);
            }
        }
    ?>


    <div class="ts-music-detail">

        <header class="ts-music-header">
            <h1 class="ts-music-title">
                <?php echo e($title); ?> | Download Music MP3

                <?php if($artist->Featuring): ?>
                    <span class="ts-music-featuring">
                        feat. <?php echo e($artist->Featuring); ?>

                    </span>
                <?php endif; ?>
            </h1>

            <div class="ts-music-meta">
                <a
                    class="ts-music-posted-by"
                    href="<?php echo e(route(
                        'pages.songs_posted_by',
                        \Illuminate\Support\Str::slug($artist->posted_by_name)
                    )); ?>"
                >
                    Posted by:
                    <strong><?php echo e($artist->posted_by_name); ?></strong>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                </a>

                <?php if($artist->created_at): ?>
                    <span class="ts-music-meta-separator">•</span>

                    <time
                        class="ts-music-date"
                        datetime="<?php echo e(\Illuminate\Support\Carbon::parse($artist->created_at)->toDateString()); ?>"
                    >
                        <?php echo e(\Illuminate\Support\Carbon::parse($artist->created_at)->format('M d, Y')); ?>

                    </time>
                <?php endif; ?>
            </div>
        </header>

        <section class="ts-music-details-card">
            <div class="ts-music-info-bar">

                <?php if($artist->producedby): ?>
                    <div class="ts-info-item">
                        <span class="ts-info-label">Produced By:</span>
                        <span class="ts-info-value">
                            <?php echo e($artist->producedby); ?>

                        </span>
                    </div>
                <?php endif; ?>

                <?php if($artist->YearOfRelease): ?>
                    <div class="ts-info-item">
                        <span class="ts-info-label">Recorded:</span>

                        <a
                            class="ts-info-value"
                            href="<?php echo e(route('pages.songs_released_year', [
                                'year' => $artist->YearOfRelease,
                            ])); ?>" style="text-decoration:none";
                        >
                            <?php echo e($artist->YearOfRelease); ?>

                        </a>
                    </div>
                <?php endif; ?>

                <div class="ts-info-item">
                    <span class="ts-info-label">Category:</span>
                    <span class="ts-info-value">
                        <a href="<?php echo e(route('pages.music_all')); ?>">
                            Latest Music
                        </a>
                    </span>
                </div>

                <?php if($album): ?>
                    <div class="ts-info-item">
                        <span class="ts-info-label">Album:</span>
                        <span class="ts-info-value">
                            <a href="<?php echo e(route('pages.album_details', [
                                $album->id,
                                \Illuminate\Support\Str::slug($album->title),
                            ])); ?>">
                                <?php echo e($album->title); ?>

                            </a>
                        </span>
                    </div>
                <?php endif; ?>

                <?php if(in_array($artist->country_id, ['naija', 'ghana', 'african'], true)): ?>
                    <div class="ts-info-item">
                        <span class="ts-info-label">Country:</span>
                        <span class="ts-info-value">
                            <a href="<?php echo e(route('pages.musics', $artist->country_id)); ?>">
                                <?php echo e(ucfirst($artist->country_id)); ?> 
                            </a>
                        </span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="ts-music-body">
                <div class="ts-music-cover">
                    <img
                        src="<?php echo e(!empty($artist->CoverUrl)
                            ? asset('images/listing/' . ltrim($artist->CoverUrl, '/'))
                            : asset('images/listing/placeholder.jpg')); ?>"
                        alt="<?php echo e($artist->Title ?? 'Music cover'); ?>"
                        onerror="this.onerror=null;this.src='<?php echo e(asset('images/listing/placeholder.jpg')); ?>';"
                    >
                </div>

                <div class="ts-music-content">
                    <h2 class="ts-song-artist"><?php echo e($artistName); ?></h2>

                    <div class="ts-song-title-row">
                        <h3 class="ts-song-title">
                            <?php echo e($artist->TrackTitle); ?>

                        </h3>

                        <?php if($artist->Featuring): ?>
                            <span class="ts-song-featuring">
                                feat. <?php echo e($artist->Featuring); ?>

                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="ts-audio-box">
                        <?php if($mediaUrl): ?>
                            <button
                                type="button"
                                class="ts-main-play"
                                id="ts-track-play"
                                aria-label="Play <?php echo e($title); ?>"
                            >
                                <i class="fa fa-play" aria-hidden="true"></i>
                            </button>

                            <audio
                                id="ts-track-audio"
                                src="<?php echo e($mediaUrl); ?>"
                                preload="none"
                            ></audio>
                        <?php else: ?>
                            <button
                                type="button"
                                class="ts-main-play"
                                aria-label="Audio unavailable"
                                disabled
                            >
                                <i class="fa fa-play" aria-hidden="true"></i>
                            </button>
                        <?php endif; ?>

                        <span class="ts-audio-heading">
                            Listen to <?php echo e($artistName); ?> - <?php echo e($artist->TrackTitle); ?> Here
                        </span>
                    </div>

                    <?php if($mediaUrl): ?>
                        <a
                            class="ts-download-button"
                            href="<?php echo e($mediaUrl); ?>"
                            download="<?php echo e(\Illuminate\Support\Str::slug($title)); ?>.mp3"
                        >
                            <i class="fa fa-download" aria-hidden="true"></i>
                            Download <?php echo e($artist->TrackTitle); ?> Mp3
                        </a>
                    <?php else: ?>
                        <button type="button" class="ts-download-button" disabled>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            Download <?php echo e($artist->TrackTitle); ?> Mp3
                        </button>
                    <?php endif; ?>

                    
                </div>
            </div>
        </section>

        <?php if($artist->introduction || $artist->TrackInfo || $artist->trackinfo1): ?>
            <section class="ts-about-song">
                <div class="ts-about-song-inner">
                    <h2 class="ts-about-heading">
                        About Song
                    </h2>

                    <div class="ts-about-text">
                        <?php $__currentLoopData = [
                            $artist->introduction,
                            $artist->TrackInfo,
                            $artist->trackinfo1,
                            $artist->trackinfo2,
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($paragraph): ?>
                                <p><?php echo e(strip_tags($paragraph)); ?></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <?php if($related->isNotEmpty()): ?>
            <section class="ts-section">
                <header class="ts-section-heading">
                    <h2>Download <?php echo e($artistName); ?> Other Songs</h2>
                </header>

                <div class="ts-music-grid">
                    <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('pages.partials.music-card', ['row' => $row], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if($artistAlbums->isNotEmpty()): ?>
            <section class="ts-section">
                <header class="ts-section-heading">
                    <h2><?php echo e($artistName); ?> Albums</h2>
                </header>

                <div class="ts-albums-grid">
                    <?php $__currentLoopData = $artistAlbums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('pages.partials.album-card', ['row' => $row], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if($artistVideos->isNotEmpty()): ?>
            <section class="ts-section">
                <header class="ts-section-heading">
                    <h2><?php echo e($artistName); ?> Videos</h2>
                </header>

                <div class="ts-videos-grid">
                    <?php $__currentLoopData = $artistVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('pages.partials.video-card', ['row' => $row], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if($collaborations->isNotEmpty()): ?>
            <section class="ts-section">
                <header class="ts-section-heading">
                    <h2><?php echo e($artistName); ?> Various Collaborations</h2>
                </header>

                <div class="ts-music-grid">
                    <?php $__currentLoopData = $collaborations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('pages.partials.music-card', ['row' => $row], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if($latestMusic->isNotEmpty()): ?>
            <section class="ts-section">
                <header class="ts-section-heading">
                    <h2>Latest Music</h2>
                </header>

                <div class="ts-music-grid">
                    <?php $__currentLoopData = $latestMusic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('pages.partials.music-card', ['row' => $row], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>     

    </div>


    <?php if($mediaUrl): ?>
        <script>
            const audio = document.getElementById('ts-track-audio');
            const playButton = document.getElementById('ts-track-play');
            const playIcon = playButton.querySelector('i');

            playButton.addEventListener('click', function () {
                if (audio.paused) {
                    audio.play();
                } else {
                    audio.pause();
                }
            });

            audio.addEventListener('play', function () {
                playIcon.classList.replace('fa-play', 'fa-pause');
                playButton.setAttribute('aria-label', 'Pause <?php echo e($title); ?>');
            });

            function showPlayIcon() {
                playIcon.classList.replace('fa-pause', 'fa-play');
                playButton.setAttribute('aria-label', 'Play <?php echo e($title); ?>');
            }

            audio.addEventListener('pause', showPlayIcon);
            audio.addEventListener('ended', showPlayIcon);
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/musics_detail.blade.php ENDPATH**/ ?>