

<?php
    $pageTitle = "Download {$year} Music Mp3 Here | TrendySongz";

    $description = "Download Latest {$year} Songs, Download Latest {$year} Naija Songs, Download {$year} Music mp3, download {$year} music ,latests songs, download latest Naija music, Latest Naija songs,  2Baba, tekno, tiwa savage, burna boy, zlatan, mi, ycee, flavour,phyno, rema, olamide, d prince, akon, timaya, spinall, neptune, cuppy, kizz daniel naija musics, nigerian songs";

    $keywords = "Download Latest {$year} Songs, Download Latest {$year} Naija Songs, Download {$year} Music mp3, download {$year} music, Download {$year} Songs, Download {$year} naija music, download music mp3, latests songs, latest naija songs, latest naija music, 2Baba, tekno, tiwa savage, burna boy, zlatan, mi, ycee, flavour,phyno, rema, olamide, d prince, akon, timaya, spinall, neptune, cuppy, kizz daniel, spinall, neptune, kizz daniel naija musics, nigerian songs, dj cuppy, new music, ycee, tekno, download music mp3, akon, ";

    $pageUrl = $rows->url($rows->currentPage());
?>

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($description); ?>">
    <meta name="keywords" content="<?php echo e($keywords); ?>">
    <meta name="author" content="Wilfred Moses">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e($pageUrl); ?>">

    <?php if($rows->currentPage() > 1): ?>
        <link rel="prev" href="<?php echo e($rows->previousPageUrl()); ?>">
    <?php endif; ?>

    <?php if($rows->hasMorePages()): ?>
        <link rel="next" href="<?php echo e($rows->nextPageUrl()); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo e($pageTitle); ?>">
    <meta property="og:description" content="<?php echo e($description); ?>">
    <meta property="og:url" content="<?php echo e($pageUrl); ?>">
    <meta property="og:site_name" content="TrendySongz">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="<?php echo e($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($description); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-music-page">
        <header class="ts-music-page-heading">
            <h1>
                Download <?php echo e($year); ?> Songs, Download <?php echo e($year); ?> Music Mp3,
                Download <?php echo e($year); ?> Naija Music
            </h1>

            <time class="post-date" datetime="<?php echo e(now()->toDateString()); ?>">
                <?php echo e(now()->format('M d, Y')); ?>

            </time>
        </header>

      <!--  <p>
            Download <?php echo e($year); ?> Songs here, Download <?php echo e($year); ?> Naija Music Mp3,
            download <?php echo e($year); ?> music here for popular Artistes like Davido,
            Burna Boy, Wizkid, Peruzzi, Mayorkun, etc.
        </p> -->

        <div class="ts-music-list">
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="ts-music-list-item">
                    <a class="ts-music-list-link"
                       href="<?php echo e(route('pages.musics_detail', [
                           $row->id,
                           \Illuminate\Support\Str::slug(
                               ($row->ArtistsName ?? '') . ' ' . $row->TrackTitle
                           ),
                       ])); ?>">

                        <span class="ts-music-list-cover">
                            <?php echo $__env->make('pages.partials.cover', [
                                'src' => $row->CoverUrl,
                                'folder' => '',
                            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </span>

                        <span class="ts-music-list-info">
                            <span class="ts-music-list-artist">
                                <?php echo e($row->ArtistsName ?: 'Unknown Artist'); ?>

                            </span>

                            <span class="ts-music-list-title">
                                <?php echo e($row->TrackTitle); ?>

                            </span>

                            <?php if($row->Featuring): ?>
                                <span class="ts-music-list-featuring">
                                    feat. <?php echo e($row->Featuring); ?>

                                </span>
                            <?php endif; ?>
                        </span>

                        <span class="ts-music-list-action">›</span>
                    </a>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No published <?php echo e($year); ?> songs found.</p>
            <?php endif; ?>
        </div>

        <?php if($rows->hasPages()): ?>
            <div class="ts-list-pagination">
                <?php echo e($rows->links('vendor.pagination.trendysongz')); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/songs_year.blade.php ENDPATH**/ ?>