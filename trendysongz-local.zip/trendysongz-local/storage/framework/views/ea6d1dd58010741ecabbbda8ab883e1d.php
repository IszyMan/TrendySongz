<section
    class="ts-artists-section"
    data-artist-section="<?php echo e($section); ?>"
    id="artists-<?php echo e($section); ?>"
>
    <header class="ts-section-heading">
        <h2><?php echo e($heading); ?></h2>

        <span class="ts-artist-total">
            <?php echo e($rows->total()); ?> artists
        </span>
    </header>

    <div class="ts-artist-grid">
        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $artistName = $row->ArtistsName
                    ?: $row->Stage_Name
                    ?: 'Unknown Artist';
            ?>

            <a
                class="ts-artist-card"
                href="<?php echo e(route(
                    'pages.artists_details',
                    \Illuminate\Support\Str::slug($artistName)
                )); ?>"
            >
                <span class="ts-artist-image">
                    <?php if($row->ProfilePic): ?>
                        <img
                            src="<?php echo e(asset('images/' . ltrim($row->ProfilePic, '/'))); ?>"
                            alt="<?php echo e($artistName); ?>"
                            loading="lazy"
                        >
                    <?php else: ?>
                        <span class="ts-artist-placeholder">
                            <i class="fa fa-user" aria-hidden="true"></i>
                        </span>
                    <?php endif; ?>
                </span>

                <span class="ts-artist-content">
                    <span class="ts-artist-name">
                        <?php echo e($artistName); ?>

                    </span>

                    <?php if($row->RecordLabel): ?>
                        <span class="ts-artist-record-label">
                            <?php echo e($row->RecordLabel); ?>

                        </span>
                    <?php endif; ?>

                    <span class="ts-artist-stats">
                        <span>Albums <?php echo e($row->album_count); ?></span>
                        <span>Singles <?php echo e($row->single_count); ?></span>
                    </span>

                    

                    <span class="ts-artist-view">View artist →</span>
                </span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No artists found in this section.</p>
        <?php endif; ?>
    </div>

    <?php if($rows->hasPages()): ?>
        <div class="ts-artist-pagination">
            <?php echo e($rows
                ->appends(request()->except($rows->getPageName()))
                ->appends(['section' => $section])
                ->links('vendor.pagination.trendysongz')); ?>

        </div>
    <?php endif; ?>
</section><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/partials/artist-country-section.blade.php ENDPATH**/ ?>