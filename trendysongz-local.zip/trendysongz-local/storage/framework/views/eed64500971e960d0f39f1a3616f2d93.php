<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Dashboard</h1>
    <div class="admin-grid">
        <div class="admin-panel"><strong><?php echo e($artistsCount); ?></strong><p>Artistes</p></div>
        <div class="admin-panel"><strong><?php echo e($audioCount); ?></strong><p>Audio listings</p></div>
        <div class="admin-panel"><strong><?php echo e($videoCount); ?></strong><p>Video listings</p></div>
        <div class="admin-panel"><strong><?php echo e($draftCount); ?></strong><p>Unpublished listings</p></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>