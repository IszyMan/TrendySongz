

<?php
    $pageTitle = 'Download Latest Songs Posted by ' . $poster->name . ' | TrendySongz';

    $description = 'Download the latest songs posted by ' . $poster->name
        . ' on TrendySongz. Browse and download music MP3s.';

    $keywords = 'songs posted by ' . $poster->name
        . ', download music mp3, latest songs, TrendySongz';

    $pageUrl = $rows->url($rows->currentPage());
?>

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($description); ?>">
    <meta name="keywords" content="<?php echo e($keywords); ?>">
    <meta name="author" content="<?php echo e($poster->name); ?>">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e($pageUrl); ?>">

    <?php if($rows->currentPage() > 1): ?>
        <link rel="prev" href="<?php echo e($rows->previousPageUrl()); ?>">
    <?php endif; ?>

    <?php if($rows->hasMorePages()): ?>
        <link rel="next" href="<?php echo e($rows->nextPageUrl()); ?>">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo e($pageTitle); ?>">
    <meta property="og:description" content="<?php echo e($description); ?>">
    <meta property="og:url" content="<?php echo e($pageUrl); ?>">
    <meta property="og:site_name" content="TrendySongz">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="<?php echo e($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($description); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-music-page">
        <header class="ts-music-page-heading">
            <h1>Download Latest Songs Posted By <?php echo e($poster->name); ?></h1>

            <time class="post-date" datetime="<?php echo e(now()->toDateString()); ?>">
                <?php echo e(now()->format('M d, Y')); ?>

            </time>
        </header>

        <div class="ts-music-list">
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="ts-music-list-item">
                    <a class="ts-music-list-link"
                       href="<?php echo e(route('pages.musics_detail', [
                           $row->id,
                           \Illuminate\Support\Str::slug(
                               ($row->ArtistsName ?? '') . ' ' . $row->TrackTitle
                           ),
                       ])); ?>">

                        <span class="ts-music-list-cover">
                            <?php echo $__env->make('pages.partials.cover', [
                                'src' => $row->CoverUrl,
                                'folder' => '',
                            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </span>

                        <span class="ts-music-list-info">
                            <span class="ts-music-list-artist">
                                <?php echo e($row->ArtistsName ?: 'Unknown Artist'); ?>

                            </span>

                            <span class="ts-music-list-title">
                                <?php echo e($row->TrackTitle); ?>

                            </span>

                            <?php if($row->Featuring): ?>
                                <span class="ts-music-list-featuring">
                                    feat. <?php echo e($row->Featuring); ?>

                                </span>
                            <?php endif; ?>
                        </span>

                        <span class="ts-music-list-action">›</span>
                    </a>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No published songs found for <?php echo e($poster->name); ?>.</p>
            <?php endif; ?>
        </div>

        <?php if($rows->hasPages()): ?>
            <div class="ts-list-pagination">
                <?php echo e($rows->links('vendor.pagination.trendysongz')); ?>

            </div>
        <?php endif; ?>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/pages/songs_posted_by.blade.php ENDPATH**/ ?>