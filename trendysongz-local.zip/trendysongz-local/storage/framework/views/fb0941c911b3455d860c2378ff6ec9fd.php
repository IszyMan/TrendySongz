<?php $__env->startSection('title', 'TrendySongz - Nigerian Top Music Download Website for Trending Songs'); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="Download all the latest Nigerian music, videos, DJ mixes, albums and trending songs on TrendySongz.">
    <meta name="keywords" content="latest Nigerian music, Nigerian songs, download Nigerian music, Naija music, Nigerian albums, Nigerian DJ mix, Nigerian music videos">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e(url('/')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('facebook_meta'); ?>
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="TrendySongz">
    <meta property="og:title" content="TrendySongz - Nigerian Top Music Download Website for Trending Songs">
    <meta property="og:description" content="Download all the latest Nigerian music, videos, DJ mixes, albums and trending songs on TrendySongz.">
    <meta property="og:url" content="<?php echo e(url('/')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('twitter_meta'); ?>
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="TrendySongz - Nigerian Top Music Download Website for Trending Songs">
    <meta name="twitter:description" content="Download all the latest Nigerian music, videos, DJ mixes, albums and trending songs on TrendySongz.">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="ts-home">
        <header class="ts-home-heading">
            <h1>Latest Nigerian Music</h1>

            <time datetime="<?php echo e(now()->toDateString()); ?>" class="post-date">
                <?php echo e(now()->format('M d, Y')); ?>

            </time>
            
        </header>

        <section class="ts-section">            

            <div class="ts-music-grid">
                <?php $__empty_1 = true; $__currentLoopData = $music; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a
                        class="ts-music-card"
                        href="<?php echo e(route(
                            $row->ListingType === 'video' ? 'pages.videos_detail' : 'pages.musics_detail',
                            [
                                $row->id,
                                \Illuminate\Support\Str::slug(
                                    ($row->ArtistsName ?? '') . ' ' . $row->TrackTitle
                                ),
                            ]
                        )); ?>"
                    >
                        <div class="ts-music-cover">
                            <img
                                src="<?php echo e(!empty($row->CoverUrl)
                                    ? asset('images/listing/' . ltrim($row->CoverUrl, '/'))
                                    : asset('images/listing/placeholder.jpg')); ?>"
                                alt="<?php echo e($row->TrackTitle); ?> cover"
                                loading="lazy"
                                onerror="this.onerror=null;this.src='<?php echo e(asset('images/listing/placeholder.jpg')); ?>';"
                            >

                            <span class="ts-music-overlay">
                                <span class="ts-play-button">▶</span>
                            </span>
                        </div>

                        <div class="ts-music-info">
                            <span class="ts-home-music-artist">
                                <?php echo e($row->ArtistsName ?: 'Unknown Artist'); ?>

                            </span>

                            <div class="ts-home-music-title-row">
                                <span class="ts-home-music-title"><?php echo e($row->TrackTitle); ?></span>

                                <?php if($row->Featuring): ?>
                                    <span class="ts-home-music-featuring">
                                        <span>feat.</span> <?php echo e($row->Featuring); ?>

                                    </span>
                                <?php endif; ?>
                            </div>

                            <?php if($row->producedby): ?>
                                <span class="ts-home-music-producer">
                                    Produced by <?php echo e($row->producedby); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>More music is coming soon.</p>
                <?php endif; ?>
            </div>

            <p class="ts-section-button">
                <a href="<?php echo e(route('pages.musics', 'naija')); ?>">View all music →</a>
            </p>
        </section>

        <section class="ts-section ts-videos-section">
            <header class="ts-section-heading">
                <h2>Latest Videos</h2>
            </header>

            <div class="ts-videos-grid">
                <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('pages.partials.video-card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>More videos are coming soon.</p>
                <?php endif; ?>
            </div>

            <p class="ts-section-button">
                <a href="<?php echo e(route('pages.videos_all')); ?>">View all videos →</a>
            </p>
        </section>

        <section class="ts-section ts-latest-albums">
            <header class="ts-section-heading">
                <h2>Latest Albums</h2>
                <a class="ts-section-link" href="<?php echo e(route('pages.album')); ?>">View all →</a>
            </header>

            <div class="ts-albums-grid">
                <?php $__empty_1 = true; $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('pages.partials.album-card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No albums found.</p>
                <?php endif; ?>
            </div>
        </section>

        <section class="ts-section ts-djmix-section">
            <header class="ts-section-heading">
                <h2>Latest DJ Mixes</h2>
            </header>

            <div class="ts-djmix-list">
                <?php $__empty_1 = true; $__currentLoopData = $mixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('pages.partials.mix-card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No DJ mixes found.</p>
                <?php endif; ?>
            </div>

            <p class="ts-section-button">
                <a href="<?php echo e(route('pages.djmix')); ?>">View all mixes →</a>
            </p>
        </section>

        <section class="ts-section ts-music-news-page">
            <header class="ts-section-heading">
                <h2>Music News</h2>
            </header>

            <div class="ts-music-news-list">
                <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('pages.partials.news-card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No news found.</p>
                <?php endif; ?>
            </div>

            <p class="ts-section-button">
                <a href="<?php echo e(route('pages.celebrity_news')); ?>">View all news →</a>
            </p>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendysongz-local\resources\views/home.blade.php ENDPATH**/ ?>